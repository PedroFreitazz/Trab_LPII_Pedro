# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'vendas.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(798, 534)
        MainWindow.setStyleSheet(u"background-color: rgb(60, 187, 255);")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.groupBox_2 = QGroupBox(self.centralwidget)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.groupBox_2.setGeometry(QRect(50, 10, 711, 311))
        font = QFont()
        font.setPointSize(14)
        font.setBold(True)
        font.setWeight(75)
        self.groupBox_2.setFont(font)
        self.label_3 = QLabel(self.groupBox_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(50, 50, 101, 31))
        font1 = QFont()
        font1.setPointSize(15)
        self.label_3.setFont(font1)
        self.label_4 = QLabel(self.groupBox_2)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(60, 100, 81, 41))
        self.label_4.setFont(font1)
        self.label_5 = QLabel(self.groupBox_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(70, 150, 81, 41))
        self.label_5.setFont(font1)
        self.preco = QLineEdit(self.groupBox_2)
        self.preco.setObjectName(u"preco")
        self.preco.setGeometry(QRect(150, 200, 181, 41))
        font2 = QFont()
        font2.setPointSize(12)
        self.preco.setFont(font2)
        self.preco.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.label_6 = QLabel(self.groupBox_2)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(70, 200, 81, 41))
        self.label_6.setFont(font1)
        self.cbprod = QComboBox(self.groupBox_2)
        self.cbprod.setObjectName(u"cbprod")
        self.cbprod.setGeometry(QRect(150, 46, 491, 41))
        self.cbprod.setFont(font2)
        self.cbprod.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.cbclien = QComboBox(self.groupBox_2)
        self.cbclien.setObjectName(u"cbclien")
        self.cbclien.setGeometry(QRect(150, 100, 491, 41))
        self.cbclien.setFont(font2)
        self.cbclien.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.quant = QSpinBox(self.groupBox_2)
        self.quant.setObjectName(u"quant")
        self.quant.setGeometry(QRect(150, 150, 111, 41))
        self.quant.setFont(font2)
        self.quant.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.preco_2 = QLineEdit(self.groupBox_2)
        self.preco_2.setObjectName(u"preco_2")
        self.preco_2.setGeometry(QRect(150, 260, 181, 41))
        self.preco_2.setFont(font2)
        self.preco_2.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.label_7 = QLabel(self.groupBox_2)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(75, 260, 71, 41))
        self.label_7.setFont(font1)
        self.groupBox_3 = QGroupBox(self.centralwidget)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.groupBox_3.setGeometry(QRect(50, 330, 721, 141))
        font3 = QFont()
        font3.setPointSize(12)
        font3.setBold(False)
        font3.setWeight(50)
        self.groupBox_3.setFont(font3)
        self.groupBox_3.setAlignment(Qt.AlignCenter)
        self.btcadastrar = QPushButton(self.groupBox_3)
        self.btcadastrar.setObjectName(u"btcadastrar")
        self.btcadastrar.setGeometry(QRect(30, 60, 181, 61))
        font4 = QFont()
        font4.setPointSize(12)
        font4.setBold(True)
        font4.setWeight(75)
        self.btcadastrar.setFont(font4)
        self.btcadastrar.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        icon = QIcon()
        icon.addFile(u"../icones/cadastro.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btcadastrar.setIcon(icon)
        self.btcadastrar.setIconSize(QSize(40, 40))
        self.pushButton_2 = QPushButton(self.groupBox_3)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(270, 60, 181, 61))
        self.pushButton_2.setFont(font4)
        self.pushButton_2.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        icon1 = QIcon()
        icon1.addFile(u"../icones/2392275.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_2.setIcon(icon1)
        self.pushButton_2.setIconSize(QSize(40, 40))
        self.btfechar = QPushButton(self.groupBox_3)
        self.btfechar.setObjectName(u"btfechar")
        self.btfechar.setGeometry(QRect(510, 60, 181, 61))
        self.btfechar.setFont(font4)
        self.btfechar.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"")
        icon2 = QIcon()
        icon2.addFile(u"../icones/download.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btfechar.setIcon(icon2)
        self.btfechar.setIconSize(QSize(55, 55))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 798, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("MainWindow", u"Cadastro de Vendas", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Produto:", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Cliente:", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Quant:", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"Pre\u00e7o:", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"Total:", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("MainWindow", u"Escolha uma op\u00e7\u00e3o", None))
        self.btcadastrar.setText(QCoreApplication.translate("MainWindow", u"Cadastrar", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Listar dados", None))
        self.btfechar.setText(QCoreApplication.translate("MainWindow", u"Fechar", None))
    # retranslateUi

