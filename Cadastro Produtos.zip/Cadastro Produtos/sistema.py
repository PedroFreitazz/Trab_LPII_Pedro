from PyQt5 import  uic,QtWidgets
import mysql.connector
from reportlab.pdfgen import canvas
from PyQt5.QtWidgets import QMessageBox
from pyUFbr.baseuf import ufbr
from ibge.localidades import *
import pycep_correios
from pycep_correios import get_address_from_cep, WebService
import re
from random import randint



numero_id = 0

banco = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="",
    database="sistema"
)

def funcao_principal():
    desc = formulario.lineEdit_2.text()
    preco = formulario.lineEdit_3.text()

    categoria = ""
    
    if formulario.radioButton.isChecked() :
        categoria ="Informatica"
    elif formulario.radioButton_2.isChecked() :     
        categoria ="Alimentos"
    else :
         categoria ="Eletronicos"

    banco._open_connection()
    cursor = banco.cursor()
    comando_SQL = "INSERT INTO produtos (descricao,preco,categoria) VALUES (%s,%s,%s)"
    dados = (str(desc),str(preco),categoria)
    cursor.execute(comando_SQL,dados)
    banco.commit()
    banco.close()
    formulario.lineEdit_2.setText("")
    formulario.lineEdit_3.setText("")

def chama_segunda_tela():
    segunda_tela.show()

    banco._open_connection()
    cursor = banco.cursor()
    comando_SQL = "SELECT * FROM produtos"
    cursor.execute(comando_SQL)
    dados_lidos = cursor.fetchall()

    segunda_tela.tableWidget.setRowCount(len(dados_lidos))
    segunda_tela.tableWidget.setColumnCount(5)

    for i in range(0, len(dados_lidos)):
        for j in range(0, 4):
           segunda_tela.tableWidget.setItem(i,j,QtWidgets.QTableWidgetItem(str(dados_lidos[i][j]))) 
  

def gerar_pdf():
    cursor = banco.cursor()
    comando_SQL = "SELECT * FROM produtos"
    cursor.execute(comando_SQL)
    dados_lidos = cursor.fetchall()
    y = 0
    pdf = canvas.Canvas("cadastro_produtos.pdf")
    pdf.setFont("Times-Bold", 25)
    pdf.drawString(200,800, "Produtos cadastrados:")
    pdf.setFont("Times-Bold", 18)

    pdf.drawString(10,750, "ID")
    pdf.drawString(110,750, "PRODUTO")
    pdf.drawString(210,750, "PREÇO")
    pdf.drawString(310,750, "CATEGORIA")
    

    for i in range(0, len(dados_lidos)):
        y = y + 50
        pdf.drawString(10,750 - y, str(dados_lidos[i][0]))
        pdf.drawString(110,750 - y, str(dados_lidos[i][1]))
        pdf.drawString(210,750 - y, str(dados_lidos[i][2]))
        pdf.drawString(310,750 - y, str(dados_lidos[i][3]))
 #       pdf.drawString(410,750 - y, str(dados_lidos[i][4]))

    pdf.save()
    print("PDF FOI GERADO COM SUCESSO!")

def excluir_dados():
    linha = segunda_tela.tableWidget.currentRow()
    segunda_tela.tableWidget.removeRow(linha)

    cursor = banco.cursor()
    cursor.execute("SELECT id FROM produtos")
    dados_lidos = cursor.fetchall()
    valor_id = dados_lidos[linha][0]
    cursor.execute("DELETE FROM produtos WHERE id_produto="+ str(valor_id))
    banco.commit()

def editar_dados():
    global numero_id #variável global que serve para mostrar o id que está sendo mostrado na tela

    linha = segunda_tela.tableWidget.currentRow()
    
    cursor = banco.cursor()
    cursor.execute("SELECT id_produto FROM produtos")
    dados_lidos = cursor.fetchall()
    valor_id = dados_lidos[linha][0]
    cursor.execute("SELECT * FROM produtos WHERE id_produto="+ str(valor_id))
    produto = cursor.fetchall() #pega todos os resultados do select e armazena em uma tupla
    tela_editar.show()

    tela_editar.lineEdit.setText(str(produto[0][0]))
    tela_editar.lineEdit_2.setText(str(produto[0][1]))
    tela_editar.lineEdit_3.setText(str(produto[0][2]))
    tela_editar.lineEdit_4.setText(str(produto[0][3]))
    #tela_editar.lineEdit_5.setText(str(produto[0][4]))
    numero_id = valor_id

def salvar_valor_editado():
    global numero_id #pega o ID

    # ler dados do lineEdit
    id = tela_editar.lineEdit.text()
    descricao = tela_editar.lineEdit_2.text()
    preco = tela_editar.lineEdit_3.text()
    categoria = tela_editar.lineEdit_4.text()

    # atualizar os dados no banco
    cursor = banco.cursor()
    cursor.execute("UPDATE produtos SET id_produto = '{}', descricao = '{}', preco = '{}', categoria ='{}' WHERE id_produto = {}".format(id,descricao,preco,categoria,numero_id))
    banco.commit()
    #atualizar as janelas
    tela_editar.close()
    segunda_tela.close()
    chama_segunda_tela()

def logar():
    primeira_tela.label_4.setText("")
    usuario = primeira_tela.lineEdit.text()
    senha = (primeira_tela.lineEdit_2.text())

    banco._open_connection()
    cursor = banco.cursor()
    cursor.execute("SELECT senha, usuario FROM user WHERE senha='{}'".format(senha))
    senha_bd = cursor.fetchall() 
    banco.close()
    if (senha_bd[0][0]==senha) and (senha_bd[0][1]==usuario):
        primeira_tela.close()
        tela_menu.show()
    else:
        primeira_tela.label_4.setText("Dados de login incorretos!")
    
def cadastro_prod():
  formulario.show() 

def novo_user():
   tela_user.show()
   

def cadastro_clientes():
    tela_clientes.show()
    mostra_estados()
   
def cadastro_user():
    nome=tela_user.lineEdit.text()
    usuario=tela_user.lineEdit_2.text()
    senha=tela_user.lineEdit_3.text()
    senha2=tela_user.lineEdit_4.text() 
    if senha==senha2:
      banco._open_connection()
      cursor = banco.cursor()
      comando_SQL = "INSERT INTO user (senha, usuario, nome) VALUES (%s,%s,%s)"
      dados = (senha, usuario, nome)
      cursor.execute(comando_SQL,dados)
      banco.commit()
      banco.close()
      QMessageBox.about(tela_user,"Aviso","Usuário cadastrado com sucesso")
      tela_user.close()
    else:
        QMessageBox.about(tela_user,"Atenção","Senhas incorretas, digite novamente")
        tela_user.lineEdit_3.clear()
        tela_user.lineEdit_4.clear()
        tela_user.lineEdit_3.setFocus()

def mostra_estados():
        estados = (ufbr.list_uf)
        tela_clientes.cbest.setEditable(True) 
        tela_clientes.cbest.addItems(estados) 

def mostra_estados2():
        estados = Estados()
        tela_clientes.cbest.setEditable(True) 
        tela_clientes.cbest.addItems(estados.getSigla()) 

def mostra_cidades():
    cidades=""
    filtro=""
    tela_clientes.cbcid.clear()
    filtro=tela_clientes.cbest.currentText()
    cidades= (ufbr.list_cidades(filtro))  
    tela_clientes.cbcid.setEditable(True) 
    tela_clientes.cbcid.addItems(cidades)    
    
def mostra_cidades2():
    idades=""
    filtro=""
    tela_clientes.cbcid.clear()
    filtro=tela_clientes.cbest.currentText()
    cidades= Municipios()  
    tela_clientes.cbcid.setEditable(True) 
    tela_clientes.cbcid.addItems(cidades.getNome())  

def consulta_cep():
    #endereco = pycep_correios.consultar_cep(tela_clientes.lcep.Text)
    #cep=int(tela_clientes.lcep.text)
    endereco = get_address_from_cep("96065420", webservice=WebService.VIACEP)
    tela_clientes.lender.Text=endereco()
    
#def mostra_produtos():
#      banco._open_connection()
#      cursor = banco.cursor()
#      comando_SQL = "SELECT id,descricao from produtos"
#      tela_clientes.cbprod.addItems(comando_SQL)
      #produtos_bd = cursor.fetchall()
      #valor_id = produtos_bd[0][0]
      #print(valor_id)
        #tela_clientes.cbprod.addItems(produtos_bd[0])

def cadastro_clientes2():
    nome = tela_clientes.lnome.text()
    ender = tela_clientes.lender.text()
    email = tela_clientes.lemail.text()
    tel = tela_clientes.ltel.text()
    cpf = tela_clientes.lcpf.text()
    cep = tela_clientes.lcep.text()
    est= tela_clientes.cbest.currentText()
    cid = tela_clientes.cbcid.currentText()
    banco._open_connection()
    cursor = banco.cursor()
    comando_SQL = "INSERT INTO clientes (nome, endereco, telefone, email, cidade, estado, cpf, cep) VALUES (%s,%s,%s,%s,%s,%s, %s,%s)"
    dados = (str(nome),str(ender),str(tel), str(email),(cid), str(est), str(cpf), str(cep))
    cursor.execute(comando_SQL,dados)
    banco.commit()
    banco.close()
    QMessageBox.about(tela_clientes,"Clientes", "Cliente inserido com sucesso!")
    

def valida_cpf():
 ValorCPF = tela_clientes.lcpf.text()
 entrada = re.findall("\d", ValorCPF) # remover caracteres NÃO numéricos

# validar quantidade de caracteres digitados
 if len(ValorCPF) > 14 or len(entrada) < 11 or len(entrada) > 11:
    QMessageBox.about(tela_clientes,"CPF", "CPF Inválido!")

# verificar se todos os dígitos são iguais
 else:
    valid = 0
    for dig in range(0, 11):
        valid += int(entrada[dig])
        dig += 1
    if int(entrada[0]) == valid / 11:
        QMessageBox.about(tela_clientes,"CPF", "CPF Inválido!")

    # rotina de cálculos do dígito verificador do CPF
    else:
        # verificação do 10º dígito verificador
        soma = 0
        count = 10
        for i in range(0, len(entrada)-2):
            soma = soma + (int(entrada[i])*count)
            i+=1
            count-=1
        dg1 = 11-(soma%11)
        if dg1 >= 10:
            dg1 = 0

        # verificação do 11º dígito verificador
        soma = 0
        count = 10
        for j in range(1, len(entrada)-1):
            soma = soma + (int(entrada[j])*count)
            j+=1
            count-=1
        dg2 = 11-(soma%11)
        if dg2 >= 10:
            dg2 = 0

        # mensagem ao usuário
        if int(entrada[9]) != dg1 or int(entrada[10]) != dg2:
             QMessageBox.about(tela_clientes,"CPF", "CPF Inválido!")
        else: 
             QMessageBox.about(tela_clientes,"CPF", "CPF Válido!")

def fechar():
    sair = QMessageBox.question(tela_clientes, "Saindo do sistema", "Deseja mesmo sair do sistema?", QMessageBox.Yes, QMessageBox.No)
    if sair == QMessageBox.Yes:
        tela_clientes.close()

def vendas():
    tela_vendas.show()
    banco._open_connection()
    cursor = banco.cursor()
    cursor.execute("SELECT descricao FROM produtos")
    produto = cursor.fetchall() 
    linha=0
    for i in produto:
        tela_vendas.cbprod.addItem(str(produto[linha][0]))
        linha=linha+1
    
    cursor.execute("SELECT nome FROM clientes")
    cliente = cursor.fetchall() 
    linha=0
    for i in cliente:
        tela_vendas.cbclien.addItem(str(cliente[linha][0]))
        linha=linha+1
        
def cadastro_vendas():
    produto = tela_vendas.cbprod.currentText()
    cliente = tela_vendas.cbclien.currentText()
    quant = tela_vendas.quant.text()
    preco = tela_vendas.preco.text()
    
    #procura o código do produto na tabela de produtos para gravar na tabela de vendas
    banco._open_connection()
    cursor = banco.cursor()
    cursor.execute("SELECT id_produto, descricao FROM produtos WHERE descricao='{}'".format(produto))
    dados_lidos = cursor.fetchall()
    id_produto= dados_lidos[0][0]
 
   #procura o código do clientes na tabela de clientes para gravar na tabela de vendas
    cursor = banco.cursor()
    cursor.execute("SELECT id_cliente, nome FROM clientes WHERE nome='{}'".format(cliente))
    dados_lidos = cursor.fetchall()
    id_cliente= dados_lidos[0][0]
    
    #grava os dados na tabela de vendas
    cursor = banco.cursor()
    comando_SQL = "INSERT INTO vendas (id_produto, quantidade, valor_unit, id_cliente) VALUES (%s,%s,%s,%s)"
    dados = (id_produto, quant, preco, id_cliente)
    cursor.execute(comando_SQL,dados)
    banco.commit()
    banco.close()
    QMessageBox.about(tela_clientes,"Vendas", "Vendas inseridas com sucesso!")     

def pesquisar_prod():
    linha = segunda_tela.tableWidget.currentRow()
    
    cursor = banco.cursor()
    cursor.execute("SELECT id_produto FROM produtos")
    dados_lidos = cursor.fetchall()
    valor_id = dados_lidos[linha][0]
    cursor.execute("SELECT * FROM produtos WHERE id_produto="+ str(valor_id))
    produto = cursor.fetchall() #pega todos os resultados do select e armazena em uma tupla
    print(produto)
  #  segunda_tela.tableWidget.setRowCount(len(produto))
    segunda_tela.tableWidget.setColumnCount(4)

    

app=QtWidgets.QApplication([])
primeira_tela=uic.loadUi("tela_login.ui")
formulario=uic.loadUi("produtos.ui")
segunda_tela=uic.loadUi("listar_dados.ui")
tela_editar=uic.loadUi("menu_editar.ui")
tela_menu=uic.loadUi("menu.ui")
tela_user=uic.loadUi("tela_cadastro_user.ui")
tela_clientes=uic.loadUi("clientes.ui")
tela_vendas=uic.loadUi("vendas.ui")
formulario.pushButton.clicked.connect(funcao_principal)
formulario.pushButton_2.clicked.connect(chama_segunda_tela)
segunda_tela.pushButton.clicked.connect(gerar_pdf)
segunda_tela.btexcluir.clicked.connect(excluir_dados)
segunda_tela.bteditar.clicked.connect(editar_dados)
tela_editar.btsalvar.clicked.connect(salvar_valor_editado)
primeira_tela.btlogin.clicked.connect(logar)
tela_menu.btprod.clicked.connect(cadastro_prod)
tela_menu.btclien.clicked.connect(cadastro_clientes)
tela_menu.btvendas.clicked.connect(vendas)
tela_user.btsalvar.clicked.connect(cadastro_user)
primeira_tela.btcadastrar.clicked.connect(novo_user)
tela_clientes.pbfiltrar.clicked.connect(mostra_cidades)
tela_clientes.verificacpf.clicked.connect(valida_cpf)
tela_clientes.btcadastrar.clicked.connect(cadastro_clientes2)
tela_vendas.btcadastrar.clicked.connect(cadastro_vendas)
segunda_tela.btpesq.clicked.connect(pesquisar_prod)
primeira_tela.show()
app.exec()