<?php
include_once("conecta.php"); // Certifique-se de que este arquivo contém a conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os valores do formulário
    $Temp_min = $_POST["Temp_min"];
    $Temp_max = $_POST["Temp_max"];
    $Umid_min = $_POST["Umid_min"];
    $Umid_max = $_POST["Umid_max"];
    $Composteira_id = $_POST["Composteira_id"];

    // Prepara a consulta SQL para inserir os dados na tabela "Regra"
    $sql = "INSERT INTO Regra (Temp_min, Temp_max, Umid_min, Umid_max, fk_Composteira_Composteira_ID) 
            VALUES ('$Temp_min', '$Temp_max', '$Umid_min', '$Umid_max', '$Composteira_id')";

    // Executa a consulta e verifica se foi bem-sucedida
    if ($conn->query($sql) === TRUE) {
        echo "Regra cadastrada com sucesso.";
    } else {
        echo "Erro ao cadastrar a regra: " . $conn->error;
    }

    // Fecha a conexão com o banco de dados
    $conn->close();
}
?>
