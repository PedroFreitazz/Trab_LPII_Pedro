function fundoVermelho(){
    var elemento = document.getElementById("divUm");
    elemento.style.background = "red";
    elemento.style.width ="110px";
    elemento.style.padding = "5px";
}

function fundoAzul(){
    var elemento = document.getElementById("divUm");
    elemento.style.background = "blue";
    elemento.style.width ="110px";
    elemento.style.padding = "5px";
}

function estilizarDiv(){
    var elemento = document.getElementById("divUm");
    elemento.style.borderRadius = "7px";
    elemento.style.background = "yellow";
    elemento.style.color = "green";
    elemento.style.width ="110px";
    elemento.style.padding = "5px";
}