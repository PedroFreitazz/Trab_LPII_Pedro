package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView nome, telefone, email;
    EditText cad_nome, cad_tel, cad_email;
    Button cad_salvar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        nome = findViewById(R.id.nome);
        telefone = findViewById(R.id.telefone);
        email = findViewById(R.id.email);
        cad_nome = findViewById(R.id.cad_nome);
        cad_tel = findViewById(R.id.cad_tel);
        cad_email = findViewById(R.id.cad_email);

    }
}