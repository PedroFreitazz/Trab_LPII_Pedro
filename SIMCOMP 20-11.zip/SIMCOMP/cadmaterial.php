<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Material</title>
    <link rel="stylesheet" href="style.css">
</head>
<a class="voltar"  href="index.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
<body>
    <div class="container">
        <h1>Cadastro de Material</h1>

        <form action="inserir_material.php" method="POST">
            <div class="form-group">
                <label for="nome">Nome do Material:</label>
                <input type="text" id="nome" name="nome" required>
            </div>

            <div class="form-group">
                <label for="categoria">Categoria:</label>
                <select id="categoria" name="categoria" required>
                    <?php include_once("buscar_categorias.php"); ?>
                </select>
            </div>

            <div class="form-group">
                <button type="submit">Cadastrar Material</button>
            </div>
        </form>
        <a href="lista_materiais.php" class="listar-button">Materiais Existentes</a>

    </div>
</body>
</html>
