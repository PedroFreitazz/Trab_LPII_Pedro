package com.example.agenda;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class dbhelper extends SQLiteOpenHelper {
    private static int versao = 1;
    private static  String nomeDB = "agenda.db";
    String[] sql = {
            "CREATE TABLE CONTATOS (id INTEGER, nome TEXT, telefone TEXT, email TEXT, PRIMARY KEY(id AUTOINCREMENT));"
    };

    public dbhelper(Context context) {
        super(context, nomeDB, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        for (int i=0;i< sql.length;i++){
            db.execSQL(sql[i]);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        versao++;
        db.execSQL("DROP TABLE IF EXISTS Contatos");
        onCreate(db);
    }
    public long Update(int id, String nome, String telefone, String email){
        SQLiteDatabase db=getWritableDatabase();
        ContentValues valor=new ContentValues();
        valor.put("nome",nome);
        valor.put("telefone",telefone);
        valor.put("email",email);
        return db.update("Contatos", valor, "id=?",new String[]{String.valueOf(id)});
    }
    public long Insert (String nome, String telefone,String email){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valor = new ContentValues();
        valor.put("nome",nome);
        valor.put("telefone",telefone);
        return db.insert("Contatos",null,valor);}
    public long Delete(int id){
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("Contatos", "id=?", new String[]{String.valueOf(id)});
    }
    @SuppressLint("Range")
    public long Select(String nome, String telefone, String email){
        SQLiteDatabase db = getReadableDatabase();
        Cursor c= db.rawQuery("SELECT * FROM Contatos WHERE nome=? AND telefone=? AND email=?" ,new String[]{nome,telefone,email});
        c.moveToFirst();
        if (c.getCount()==1){
            return c.getInt(c.getColumnIndex("id"));
        }
        return-1;
    }
    public List<Contatos> SelectAll(){
        SQLiteDatabase db = getReadableDatabase();
        Cursor c= db.rawQuery("SELECT * FROM Contatos", null);
        List<Contatos> listacontatos = new ArrayList<>();
        c.moveToFirst();
        if(c.getCount()>0){
            do {
                @SuppressLint("Range") int id= c.getInt(c.getColumnIndex("id"));
                @SuppressLint("Range") String nome = c.getString(c.getColumnIndex("nome"));
                @SuppressLint("Range") String telefone = c.getString(c.getColumnIndex("telefone"));
                @SuppressLint("Range") String email = c.getString(c.getColumnIndex("email"));
                listacontatos.add(new Contatos(id,nome,telefone,email));
            }while(c.moveToNext());
        } return listacontatos;
    }
    public Contatos SelectID (int id){
        SQLiteDatabase db= getReadableDatabase();
        Cursor c= db.rawQuery("SELECT * FROM Contatos WHERE id=?", new String[]{String.valueOf(id)});
        c.moveToFirst();
        if(c.getCount()==1){
            @SuppressLint("Range") String nome = c.getString(c.getColumnIndex("nome"));
            @SuppressLint("Range") String telefone = c.getString(c.getColumnIndex("telefone"));
            @SuppressLint("Range") String email = c.getString(c.getColumnIndex("email"));
            return new Contatos(id,nome,telefone,email);
        }
        return null;
    }
}

