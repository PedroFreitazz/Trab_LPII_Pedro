from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox

def exibir_mensagem():
    dado_lido = janela.lenome.text()
    print(dado_lido)
    janela.lenome.setText("")
    if dado_lido=="":
        QMessageBox.about(janela,"Nome","Nenum nome reconhecido")
    else:
        QMessageBox.about(janela,"alerta","O nome foi registrado, olá " +dado_lido)
def fechar_tela():
    result = QMessageBox.question(janela, "Saindo do sistema", "Deseja mesmo sair do sistema?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        janela.close()
def listar_dados():
    dado_lido = janela.lenome.text()
    janela.lista.addItem(dado_lido)
def deletar():
    janela.lista.clear()
def contar_itens():
    valor = janela.lista.count()
    janela.lbconta.setText(str(valor)) 
def ordenar():
    janela.lista.sortItems()
#programa principal
app=QtWidgets.QApplication([])
janela=uic.loadUi("caixa_de_mensagem.ui")
janela.BTverificar.clicked.connect(exibir_mensagem)
janela.show()
janela.btfechar.clicked.connect(fechar_tela)
janela.btadicionar.clicked.connect(listar_dados)
janela.btexcluir.clicked.connect(deletar)
janela.btcontar.clicked.connect(contar_itens)
janela.btordenar.clicked.connect(ordenar)
app.exec()
