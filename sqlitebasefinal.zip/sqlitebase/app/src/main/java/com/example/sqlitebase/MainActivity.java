package com.example.sqlitebase;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText usu, sen;
    Button entrar,levarcad;
    dbhelper sql;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        usu=findViewById(R.id.usu);
        sen=findViewById(R.id.sen);
        entrar=findViewById(R.id.entrar);
        levarcad=findViewById(R.id.levarcad);
        sql=new dbhelper(this);
        levarcad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,cadastro.class);
                startActivity(i);
            }
        });
        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = usu.getText().toString().trim();
                String senha2=sen.getText().toString().trim();
                if (nome.isEmpty()){
                    Toast.makeText(MainActivity.this, "Insira um Usuário", Toast.LENGTH_SHORT).show();
                }
                else if(senha2.isEmpty()){
                    Toast.makeText(MainActivity.this, "Insira uma senha", Toast.LENGTH_SHORT).show();
                }
                else {
                    long resultado=sql.Select(nome,senha2);
                    if (resultado > 0){
                        Intent i = new Intent(MainActivity.this, acesso.class);
                        i.putExtra("username",nome);
                        i.putExtra("password",senha2);
                        i.putExtra("id",resultado);
                        startActivity(i);
                    }
                    else{
                        Toast.makeText(MainActivity.this, "Dados Incorretos", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}