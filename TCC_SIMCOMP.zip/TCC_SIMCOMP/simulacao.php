
<!DOCTYPE html>
<html>
<head>
    <title>Simulador de Composteira</title>
</head>
<body>
    <h1>Simulador de Composteira</h1>
    <img src="img//composteira.png" alt="Composteira" width="200" height="300">
 
    <button onclick="addWater()">
        <img src="img/agua.png" alt="Inserir Água" width="50" height="50">
    </button>
    <button onclick="advanceDays()">
        <img src="clock_icon.png" alt="Avançar 10 Dias" width="50" height="50">
    </button>

    <h2>Itens para Compostar:</h2>
    <button onclick="addToCompost('Restos de comida')">
        <img src="food_icon.png" alt="Restos de comida" width="50" height="50">
    </button>
    <button onclick="addToCompost('Folhas secas')">
        <img src="leaves_icon.png" alt="Folhas secas" width="50" height="50">
    </button>
    <button onclick="addToCompost('Papel')">
        <img src="paper_icon.png" alt="Papel" width="50" height="50">
    </button>
    <button onclick="addToCompost('Cascas de ovo')">
        <img src="img/ovo.png" alt="Cascas de ovo" width="50" height="50">
    </button>

</body>
</html>

    <script>
        function addWater() {
            updateTemperature(2);
        }

        function advanceDays() {
            updateTemperature(-1); 
            alert("Passaram-se 10 dias.");
        }

        function addToCompost(item) {
            alert(item + " adicionado à composteira.");
        }

        function updateTemperature(change) {
            var temperatureElement = document.getElementById("temperature");
            var currentTemperature = parseInt(temperatureElement.textContent);
            var newTemperature = currentTemperature + change;
            temperatureElement.textContent = newTemperature;
        }
    </script>
</body>
</html>


