package com.example.imc;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText valorpeso,valoraltura;
    Button calcular;
    TextView resultados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        valorpeso = findViewById(R.id.valorpeso);
        valoraltura = findViewById(R.id.valoraltura);
        calcular = findViewById(R.id.calcular);
        resultados = findViewById(R.id.resultado);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                double peso = Double.parseDouble(valorpeso.getText().toString());
                double altura = Double.parseDouble(valoraltura.getText().toString());

                double imc = peso / (altura *altura);

                resultados.setText(String.valueOf(imc));
            }
        });





    }
}