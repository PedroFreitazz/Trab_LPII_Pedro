<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    $matricula = $_POST["matricula"];
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $cpf = $_POST["cpf"];
    $data_nasc = $_POST["data_nasc"];

    
    include_once "conecta.php";

   
    $sql = "INSERT INTO aluno (matricula, nome, email, cpf, data_nasc) 
            VALUES ('$matricula', '$nome', '$email', '$cpf', '$data_nasc')";

    if (mysqli_query($conn, $sql)) {
        echo "Aluno cadastrado com sucesso!";
    } else {
        echo "Erro ao cadastrar aluno: " . mysqli_error($conn);
    }

    // Fechar a conexão com o banco de dados
    mysqli_close($conn);
}
?>
