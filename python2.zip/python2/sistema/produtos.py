import mysql.connector

#importar bibliotecas:
from PyQt5 import uic,QtWidgets


bd =  mysql.connector.MySQLConnection(
    host = "localhost",
    user ="root",
    password = "",
    db = "sistema"
)

def inserir_dados():
    descricao = janela.ledesc.text()
    preco = janela.lepreco.text()
    
    categoria = ""

    if janela.rbalimentos.isChecked():
        categoria = "Alimentos"
    elif janela.rbeletronicos.isChecked():
        categoria = "Eletrônicos"
    else:
        categoria = "Informática"

    print("Descrição:", descricao)
    print("Valor:", preco)

    cursor = bd.cursor()
    sql = "insert into produtos (descricao, preco, categoria) values (%s, %s, %s)"
    dados = (str(descricao), str(preco), categoria)
    cursor.execute(sql, dados)
    bd.commit()
    janela.ledesc("")
    janela.lepreco("")


#Programa principal
app = QtWidgets.QApplication([])
janela = uic.loadUi("produtos.ui")
janela.pbcadastrar.clicked.connect(inserir_dados)
janela.show()
app.exec()