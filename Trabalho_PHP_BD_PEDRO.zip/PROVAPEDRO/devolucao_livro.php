<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  // Obter os valores do formulário
  $livrosDevolvidos = isset($_POST['livros_devolvidos']) ? $_POST['livros_devolvidos'] : [];

  // Conectar ao banco de dados
  include_once "conecta.php";

  foreach ($livrosDevolvidos as $emprestimoId) {
    // Atualizar o status do livro para "disponivel" e o status da reserva para "devolvido"
    mysqli_query($conn, "UPDATE reserva SET status = '0' WHERE id = $emprestimoId");
    mysqli_query($conn, "UPDATE livro SET status = '1' WHERE id = (SELECT id_livro FROM reserva WHERE id = $emprestimoId)");
    mysqli_query($conn, "DELETE FROM reserva WHERE id = $emprestimoId"); // Remover empréstimo da tabela de reserva
  }

  // Consulta para obter a lista de empréstimos em aberto
  $sql_emprestimos = "SELECT r.id, l.titulo, a.nome, r.data_retirada, r.data_entrega FROM reserva r JOIN livro l ON r.id_livro = l.id JOIN aluno a ON r.matricula = a.matricula WHERE r.status = 'emprestado'";
  $result_emprestimos = mysqli_query($conn, $sql_emprestimos);

  if (!$result_emprestimos) {
    die("Erro na consulta: " . mysqli_error($conn));
  }

  $emprestimos = mysqli_fetch_all($result_emprestimos, MYSQLI_ASSOC);

  mysqli_close($conn);

  echo "Devolução realizada com sucesso!";
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Devolução de Livros</title>
  <link rel="stylesheet" type="text/css" href="style.css">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script>
    $(document).ready(function() {
      $("#checkTodos").change(function() {
        $("input:checkbox").prop('checked', $(this).prop("checked"));
      });
    });
  </script>
</head>
<body>
  <h1>Devolução de Livros</h1>
  <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <?php
    // Conectar ao banco de dados
    $conn = mysqli_connect("localhost", "root", "", "biblioteca");

    if ($conn === false) {
      die("Erro de conexão: " . mysqli_connect_error());
    }

    // Consulta para obter a lista de empréstimos em aberto
    $sql_emprestimos = "SELECT r.id, l.titulo, a.nome, r.data_retirada, r.data_entrega FROM reserva r JOIN livro l ON r.id_livro = l.id JOIN aluno a ON r.matricula = a.matricula WHERE r.status = 'emprestado'";
    $result_emprestimos = mysqli_query($conn, $sql_emprestimos);

    if (!$result_emprestimos) {
      die("Erro na consulta: " . mysqli_error($conn));
    }

    $emprestimos = mysqli_fetch_all($result_emprestimos, MYSQLI_ASSOC);

    mysqli_close($conn);
    ?>

    <?php if (!empty($emprestimos)): ?>
      <table>
        <tr>
          <th><input type="checkbox" id="checkTodos"></th>
          <th>Livro</th>
          <th>Aluno</th>
          <th>Data de Retirada</th>
          <th>Data de Entrega</th>
        </tr>
        <?php foreach ($emprestimos as $emprestimo): ?>
          <tr>
            <td><input type="checkbox" name="livros_devolvidos[]" value="<?php echo $emprestimo['id']; ?>"></td>
            <td><?php echo $emprestimo['titulo']; ?></td>
            <td><?php echo $emprestimo['nome']; ?></td>
            <td><?php echo $emprestimo['data_retirada']; ?></td>
            <td><?php echo $emprestimo['data_entrega']; ?></td>
          </tr>
        <?php endforeach; ?>
      </table>
      <br>
      <input type="submit" value="Realizar Devolução">
    <?php else: ?>
      <p>Não há empréstimos em aberto.</p>
    <?php endif; ?>
  </form>
  <li><a href="index.php">Voltar à Página Inicial</a></li>
</body>
</html>
