<!DOCTYPE html>
<html>
<head>
  <title>Página Inicial</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
        <?php
        if (isset($_GET['success'])) {
            echo '<p class="success-message">' . htmlspecialchars($_GET['success']) . '</p>';
        } elseif (isset($_GET['error'])) {
            echo '<p class="error-message">' . htmlspecialchars($_GET['error']) . '</p>';
        }
        ?>
<body class="index">
  <div class="logo">
    <img src="img/LOGOSIMCOMP.png" alt="Logo">
  </div>
  <div class="container index">
    <h2>Bem-Vindo</h2>
    <ul>
      <li><a href="cadcategoria.php">Cadastrar Categoria</a></li>
      <li><a href="cadmaterial.php">Cadastrar Material</a></li>
      <li><a href="criarcomp.php">Criar Composteira</a></li>
      <li><a href="regras.php">Definir Regras</a></li>
      <li><a href="simulacao.php">Simulação</a></li>


    </ul>
  </div>
</body>
</html>
