<head>
    <title>Escola PF</title>
    <link rel="stylesheet"  href="estilo.css">
</head>
<body>
    <nav class="menu">
      <ul>
        <li><a href="mostradados.php" target="_blank">Mostrar dados</a></li>
      </ul>
    </nav>
  <div>
    <h1 id="titulo">Cadastro de Alunos</h1>
    <p id="subtitulo">Complete com seus dados</p>
  </div>
  <form action="cadastra.php" method="post">
    <fieldset class="grupo">
      <div class="campo">
        <label for="nome"><strong>Nome</strong></label>
        <input type="text" name="nome" id="nome" required></input>
      </div>
      <div class="campo">
        <label form="idade"><strong>Idade</strong></label>
        <input type="number" name="idade" id="idade" required>
      </div>
      <div class="campo">
        <label form="curso"><strong>Curso</strong></label>
        <input type="text" name="curso" id="curso" required>
        <input type="submit" name="btn" value="Enviar">
        <input type="reset" name="resetar" value="Limpar">
      </div>
      </fieldset>
