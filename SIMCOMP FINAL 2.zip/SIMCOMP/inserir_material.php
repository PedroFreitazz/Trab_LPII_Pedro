<?php
include_once("conecta.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $categoria_id = $_POST["categoria"];

    $sql = "INSERT INTO Material (Nome, fk_Categoria_Categoria_ID) VALUES ('$nome', $categoria_id)";

    if ($conn->query($sql) === TRUE) {
        // Redirecione de volta à página principal com uma mensagem de sucesso
        header("Location: index.php?success=Material+cadastrado+com+sucesso");
        exit();
    } else {
        // Redirecione de volta à página principal com uma mensagem de erro
        header("Location: index.php?error=Erro+ao+cadastrar+o+material:+" . $conn->error);
        exit();
    }
}

$conn->close();
?>
