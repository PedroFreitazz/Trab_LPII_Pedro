<!DOCTYPE html>
<html>
<head>
    <title>Carrinho de Compras - Loja de Artigos Musicais</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Logo da Loja">
            <h1>Loja de Artigos Musicais</h1>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Início</a></li>
            <li><a href="produtos.php">Produtos</a></li>
            <li><a href="contato.php">Contato</a></li>
            <li><a href="carrinho.php">Carrinho</a></li> <!-- Adicione esta linha -->
        </ul>
    </nav>

    <section class="main-content">
        <h2>Seu Carrinho de Compras</h2>
        <ul class="cart-items">
            <li>
                <img src="guitar.jpg" alt="Guitarra">
                <h3>Guitarra Elétrica</h3>
                <p class="price">$499.99</p>
                <button class="remove-button">Remover</button>
            </li>
            <!-- Adicione mais itens aqui -->
        </ul>
        <p class="total-price">Total: $499.99</p>
    </section>

    <footer>
        <p>&copy; 2023 Loja de Artigos Musicais</p>
    </footer>
</body>
</html>
