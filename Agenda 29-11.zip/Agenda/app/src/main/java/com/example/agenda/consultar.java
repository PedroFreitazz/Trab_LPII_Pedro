package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.List;

public class consultar extends AppCompatActivity {
    ListView listacontato;
    Intent i;
    Button con_atualizar,con_deletar;
    List<Contatos> listacontatos2;
    ArrayAdapter<Contatos> adapter;
    int id2;
    String nome2;
    String telefone2;
    String email2;
    static final int CODIGO = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar);
    }
}