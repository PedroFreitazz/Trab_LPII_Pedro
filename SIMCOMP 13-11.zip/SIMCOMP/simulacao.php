<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Composteira</title>
    <link rel="stylesheet" href="style.css">
</head>
<a class="voltar"  href="index.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
<body>
    <div class="container">
        <h1>Simulação de Composteira</h1>
        <form action="simulacao.php" method="POST">
            <div class="form-group">
                <label for="Composteira_ID">Selecione a Composteira:</label>
                <select id="Composteira_ID" name="Composteira_ID">
                    <?php
                    include_once("conecta.php");

                    // Consulta ao banco de dados para obter as composteiras disponíveis
                    $sql = "SELECT Composteira_ID, Nome, Temperatura, Umidade FROM Composteira";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row["Composteira_ID"] . "'>" . $row["Nome"] . "</option>";
                        }
                    } else {
                        echo "Nenhuma composteira encontrada.";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit">Simular</button>
            </div>
        </form>
    </div>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $composteiraID = $_POST["Composteira_ID"];

    include_once("conecta.php");

    $sql = "SELECT mc.Material_Composteira_ID, c.impacto_na_composteira
            FROM Material_Composteira mc
            JOIN Material m ON mc.fk_Material_Material_ID = m.Material_ID
            JOIN Categoria c ON m.fk_Categoria_Categoria_ID = c.Categoria_ID
            WHERE mc.fk_Composteira_Composteira_ID = $composteiraID";
    $result = $conn->query($sql);

    $materialImproprio = false; // Flag para verificar se algum material é impróprio

    while ($row = $result->fetch_assoc()) {
        $impactoCategoria = $row["impacto_na_composteira"];

        // Verifique se o impacto_na_composteira na categoria do material é igual a 1
        if ($impactoCategoria == 1) {
            $materialImproprio = true;
            break; // Saia do loop, pois um material é impróprio
        }
    }

    // Verifique as regras da composteira
    $sqlRegras = "SELECT Temp_min, Temp_max, Umid_min, Umid_max FROM Regra WHERE fk_Composteira_Composteira_ID = $composteiraID";
    $resultRegras = $conn->query($sqlRegras);

    $temperaturaImpropria = false; // Flag para verificar a temperatura
    $umidadeImpropria = false; // Flag para verificar a umidade

    if ($resultRegras !== false && $resultRegras->num_rows > 0) {
        $rowRegras = $resultRegras->fetch_assoc();
        $tempMin = $rowRegras["Temp_min"];
        $tempMax = $rowRegras["Temp_max"];
        $umidMin = $rowRegras["Umid_min"];
        $umidMax = $rowRegras["Umid_max"];

        $sqlComposteira = "SELECT Temperatura, Umidade FROM Composteira WHERE Composteira_ID = $composteiraID";
        $resultComposteira = $conn->query($sqlComposteira);

        if ($resultComposteira !== false && $resultComposteira->num_rows > 0) {
            $rowComposteira = $resultComposteira->fetch_assoc();
            $temperaturaComposteira = $rowComposteira["Temperatura"];
            $umidadeComposteira = $rowComposteira["Umidade"];

            // Verifique temperatura e umidade e defina as flags $temperaturaImpropria e $umidadeImpropria conforme necessário
            if ($temperaturaComposteira < $tempMin || $temperaturaComposteira > $tempMax) {
                $temperaturaImpropria = true;
            }

            if ($umidadeComposteira < $umidMin || $umidadeComposteira > $umidMax) {
                $umidadeImpropria = true;
            }

            if ($materialImproprio) {
                echo "<script>alert('Material impróprio para a composteira.');</script>";
            }
            if ($temperaturaImpropria) {
                echo "<script>alert('Temperatura fora dos limites permitidos.');</script>";
            }
            if ($umidadeImpropria) {
                echo "<script>alert('Umidade fora dos limites permitidos.');</script>";
            }

            if (!$materialImproprio && !$temperaturaImpropria && !$umidadeImpropria) {
                echo "<script>alert('A simulação foi bem-sucedida.');</script>";
            }
        } else {
            echo "<script>alert('Dados da composteira não encontrados.');</script>";
        }
    } else {
        echo "<script>alert('Regras não encontradas para esta composteira.');</script>";
    }
}
?>
