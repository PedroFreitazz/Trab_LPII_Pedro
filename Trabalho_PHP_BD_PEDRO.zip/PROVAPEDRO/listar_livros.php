<!DOCTYPE html>
<html>
<head>
<title>Listar Livros</title>
<link rel="stylesheet" type="text/css" href="style.css">
</head>
<li><a href="index.php">Voltar á Pagina Inicial</a></li>

<body>
<?php
include_once "conecta.php";

$sql = "SELECT livro.id, livro.titulo, livro.autor, area.nome AS area_nome FROM livro INNER JOIN area ON livro.id_area = area.id";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  echo "<table>";
  echo "<tr><th>Título</th><th>Autor</th><th>Área</th><th>Editar</th><th>Excluir</th></tr>";
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['titulo'] . "</td>";
    echo "<td>" . $row['autor'] . "</td>";
    echo "<td>" . $row['area_nome'] . "</td>";
    echo "<td><a href='editar_livro.php?id=" . $row['id'] . "'>Editar</a></td>";
    echo "<td><a href='excluir_livro.php?id=" . $row['id'] . "' onclick='return confirm(\"Tem certeza que deseja excluir este livro?\")'>Excluir</a></td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  echo "Nenhum livro encontrado.";
}

mysqli_close($conn);
?>
</body>
</html>
