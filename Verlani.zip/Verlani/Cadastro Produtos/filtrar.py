import pandas as pd
x = pd.read_excel(r"C:\Users\")