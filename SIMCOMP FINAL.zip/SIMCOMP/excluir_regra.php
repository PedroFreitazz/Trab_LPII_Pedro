<?php
include_once "conecta.php";

// Verifica se o ID da regra foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    $mensagem = "ID da regra não fornecido.";
} else {
    $regra_id = $_GET['id'];

    // Consulta para excluir a regra
    $query_excluir_regra = "DELETE FROM Regra WHERE Regra_ID = $regra_id";
    $resultado_excluir_regra = mysqli_query($conn, $query_excluir_regra);

    // Verifica se a exclusão da regra foi bem-sucedida
    if ($resultado_excluir_regra) {
        $mensagem = "Regra excluída com sucesso.";
    } else {
        $erro_exclusao = mysqli_error($conn);

        // Verificar se o erro é devido a uma restrição de chave estrangeira
        if (strpos($erro_exclusao, 'foreign key constraint fails') !== false) {
            $mensagem = "Não é possível excluir a regra.";
        } else {
            $mensagem = "Erro ao excluir a regra: " . $erro_exclusao;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<a class="voltar"  href="listar_regra.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
    <div class="container">
        <h1>Excluir Regra</h1>

        <p><?php echo $mensagem; ?></p>

        <a href="listar_regra.php">Voltar</a>
    </div>
</body>
</html>
