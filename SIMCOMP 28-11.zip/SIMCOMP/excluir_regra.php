<?php
include_once "conecta.php";

// Verifica se o ID da regra foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    echo "ID da regra não fornecido.";
    exit;
}

$regra_id = $_GET['id'];

// Consulta para excluir a regra
$query_excluir_regra = "DELETE FROM Regra WHERE Regra_ID = $regra_id";
$resultado_excluir_regra = mysqli_query($conn, $query_excluir_regra);

// Verifica se a exclusão da regra foi bem-sucedida
if ($resultado_excluir_regra) {
    echo "Regra excluída com sucesso.";
} else {
    echo "Erro ao excluir a regra: " . mysqli_error($conn);
}
?>
