package com.example.provaplaneta;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {
    EditText valorpeso;
    RadioButton mercurio,jupiter,saturno,urano,marte,venus;
    Button calcular;
    TextView resultado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        valorpeso = findViewById(R.id.valorpeso);
        mercurio = findViewById(R.id.mercurio);
        jupiter = findViewById(R.id.jupiter);
        saturno = findViewById(R.id.saturno);
        urano = findViewById(R.id.urano);
        marte = findViewById(R.id.marte);
        venus = findViewById(R.id.venus);
        calcular = findViewById(R.id.calcular);
        resultado = findViewById(R.id.resultado);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double peso = Double.parseDouble(valorpeso.getText().toString());
                double total = 0;

                if (mercurio.isChecked()) {
                    total = peso / 10 * 0.37;
                } else if (venus.isChecked()) {
                    total = peso / 10 * 0.88;
                } else if (marte.isChecked()) {
                    total = peso / 10 * 0.38;
                } else if (jupiter.isChecked()) {
                    total = peso / 10 * 2.64;
                } else if (saturno.isChecked()) {
                    total = peso / 10 * 1.15;
                } else if (urano.isChecked()) {
                    total = peso / 10 * 1.17;
                }

                DecimalFormat df = new DecimalFormat("##,##.00");

                resultado.setText(df.format(total));
            }
        });
    }
}