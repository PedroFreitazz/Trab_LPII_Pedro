package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class atualizar extends AppCompatActivity {
    EditText actualid, atual_nome,atual_tel,atual_email;
    Button atualizar;
    dbhelper sql;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atualizar);
        actualid=findViewById(R.id.actualid);
        atual_nome=findViewById(R.id.atual_nome);
        atual_tel=findViewById(R.id.atual_tel);
        atual_email=findViewById(R.id.atual_email);
        atualizar=findViewById(R.id.atualizar);
        sql = new dbhelper(this);
        Bundle extras= getIntent().getExtras();
        int id2= extras.getInt("id");
        String nome2= extras.getString("nome");
        String tel2= extras.getString("telefone");
        String email2= extras.getString("email");
        atual_nome.setText(nome2);
        atual_tel.setText(tel2);
        atual_email.setText(email2);
        atualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            String nome= atual_nome.getText().toString();
            String telefone= atual_tel.getText().toString();
            String email= atual_email.getText().toString();
            long resultado = sql.Update(id2,nome,telefone,email);
            if (resultado>0){
                Toast.makeText(atualizar.this, "Dados Atualizados", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
                }
            else{
                Toast.makeText(atualizar.this, "Erro ao Atualizar", Toast.LENGTH_SHORT).show();

                }

            }
        });
    }

}