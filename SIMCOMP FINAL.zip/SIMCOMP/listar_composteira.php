<?php
include_once "conecta.php";

// Consulta para obter os dados da composteira
$query_composteira = "SELECT * FROM Composteira";
$resultado_composteira = mysqli_query($conn, $query_composteira);

// Verifica se a consulta foi bem-sucedida
if (!$resultado_composteira) {
    echo "Erro na consulta: " . mysqli_error($conn);
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Composteiras</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<a class="voltar"  href="criarcomp.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>

    <div class="container composteira">
        <h1>Listar Composteiras</h1>
        <a class="voltar" href="index.php">
            <img src="img/voltar.png" alt="Texto alternativo" placeholder="voltar" title="clique aqui para voltar">
        </a>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Umidade</th>
                    <th>Temperatura</th>
                    <th>Materiais</th>
                    <th>Tempo de Compostagem (dias)</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($resultado_composteira)) {
                    echo "<tr>";
                    echo "<td>{$row['Composteira_ID']}</td>";
                    echo "<td>{$row['Nome']}</td>";
                    echo "<td>{$row['Umidade']}</td>";
                    echo "<td>{$row['Temperatura']}</td>";

                    // Consulta para obter os materiais associados à composteira
                    $composteira_id = $row['Composteira_ID'];
                    $query_materiais = "SELECT Nome FROM Material
                                        JOIN Material_Composteira ON Material.Material_ID = Material_Composteira.fk_Material_Material_ID
                                        WHERE Material_Composteira.fk_Composteira_Composteira_ID = $composteira_id";
                    $resultado_materiais = mysqli_query($conn, $query_materiais);

                    // Verifica se a consulta dos materiais foi bem-sucedida
                    if (!$resultado_materiais) {
                        echo "Erro na consulta de materiais: " . mysqli_error($conn);
                        exit;
                    }

                    echo "<td>";
                    while ($material = mysqli_fetch_assoc($resultado_materiais)) {
                        echo $material['Nome'] . "<br>";
                    }
                    echo "</td>";

                    echo "<td>{$row['Tempo_Compostagem']}</td>";
                    echo "<td>";
                    echo "<a href='editar_composteira.php?id={$row['Composteira_ID']}'>Editar</a>";
                    echo "<br>";
                    echo "<a href='excluir_composteira.php?id={$row['Composteira_ID']}'>Excluir</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
