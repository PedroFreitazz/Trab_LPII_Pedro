<li><a href="index.html">Voltar a Pagina Inicial</a></li>

<?php
include_once("conecta.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $impacto = $_POST['impacto'];

    $sql = "INSERT INTO Categoria (Nome, Impacto_na_composteira) VALUES ('$nome', '$impacto')";

    if ($conn->query($sql) === TRUE) {
        echo "Categoria inserida com sucesso.";
    } else {
        echo "Erro ao inserir a categoria: " . $conn->error;
    }
}

$conn->close();
?>
