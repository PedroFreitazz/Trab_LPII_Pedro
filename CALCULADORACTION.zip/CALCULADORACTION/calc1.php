<!DOCTYPE html>
<html>
<head>
    <title>Resultado</title>
</head>
<body>
    <?php
       if(isset($_POST['num1']) && isset($_POST['num2']) && isset($_POST['op'])) {
        $num1 = $_POST['num1'];
        $num2 = $_POST['num2'];
        $operacao = $_POST['op'];
        
        switch($operacao) {
            case '+':
                $resultado = $num1 + $num2;
                break;
                
            case '-':
                $resultado = $num1 - $num2;
                break;
                
            case '*':
                $resultado = $num1 * $num2;
                break;
                
            case '/':
                $resultado = $num1 / $num2;
                break;
        }
    }
 echo "O resultado é: $resultado";
    ?>
</body>
</html>