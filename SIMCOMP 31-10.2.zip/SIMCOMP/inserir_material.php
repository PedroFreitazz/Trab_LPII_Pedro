<?php
include_once("conecta.php");

// Verifica se os dados foram enviados via POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os valores do formulário
    $nome = $_POST["nome"];
    $categoria_id = $_POST["categoria"];

    // Prepara a consulta SQL para inserir os dados na tabela "Material"
    $sql = "INSERT INTO Material (Nome, fk_Categoria_Categoria_ID) VALUES ('$nome', $categoria_id)";

    // Executa a consulta e verifica se foi bem-sucedida
    if ($conn->query($sql) === TRUE) {
        echo "Material cadastrado com sucesso.";
    } else {
        echo "Erro ao cadastrar o material: " . $conn->error;
    }
}

// Fecha a conexão com o banco de dados
$conn->close();
?>
