<?php
// Verifique se o formulário foi submetido
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recupere os valores do formulário
    $nomeComposteira = $_POST["nome"];
    $umidade = $_POST["umidade"];
    $temperatura = $_POST["temperatura"];
    $tempoCompostagem = $_POST["tempo"];
    $materiaisSelecionados = $_POST["materiais"];

    // Faça a conexão com o banco de dados (substitua as informações de conexão apropriadas)
    include_once("conecta.php"); 

    // Verifique a conexão com o banco de dados
    if ($conn->connect_error) {
        die("Erro na conexão com o banco de dados: " . $conn->connect_error);
    }

    // Insira os dados da composteira na tabela Composteira
    $sqlComposteira = "INSERT INTO Composteira (Nome, Umidade, Temperatura, Tempo_Compostagem) VALUES ('$nomeComposteira', '$umidade', '$temperatura', '$tempoCompostagem')";
    if ($conn->query($sqlComposteira) === TRUE) {
        $composteiraID = $conn->insert_id; // Obtém o ID da composteira recém-inserida
    } else {
        echo "Erro ao inserir a composteira: " . $conn->error;
    }

    // Insira os materiais selecionados na tabela Material_Composteira
    foreach ($materiaisSelecionados as $materialID) {
        $sqlMaterialComposteira = "INSERT INTO Material_Composteira ( fk_Material_Material_ID, fk_Composteira_Composteira_ID) VALUES ('$materialID', '$composteiraID')";
        if ($conn->query($sqlMaterialComposteira) !== TRUE) {
            echo "Erro ao inserir material na composteira: " . $conn->error;
        }
    }

    // Feche a conexão com o banco de dados
    $conn->close();

    // Redirecione o usuário para uma página de sucesso ou outra página desejada
    header("Location: index.php");
} else {
    echo "O formulário não foi submetido corretamente.";
}
?>
