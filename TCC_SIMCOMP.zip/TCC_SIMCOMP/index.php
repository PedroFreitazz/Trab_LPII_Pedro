<!DOCTYPE html>
<html>
<head>
  <title>Página Inicial</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="logo">
    <img src="img/logosimcomp.png">
  </div>
<div class="container">
    <h2>Seja Bem-Vindo</h2>
    <ul>
      <li><a href="simulacao.php">COMEÇAR</a></li>
    </ul>
  </div>
</body>
</html>
