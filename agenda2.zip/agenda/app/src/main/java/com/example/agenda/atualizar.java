package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class atualizar extends AppCompatActivity {

    EditText up_id, up_name, up_tel, up_email;
    Button up_salvar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atualizar);

        up_id = findViewById(R.id.up_id);
        up_name = findViewById(R.id.up_nome);
        up_tel = findViewById(R.id.up_tel);
        up_email = findViewById(R.id.up_email);
        up_salvar = findViewById(R.id.up_salvar);

    }
}