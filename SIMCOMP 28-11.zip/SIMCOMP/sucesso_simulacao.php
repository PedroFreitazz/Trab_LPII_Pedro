<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sucesso na Simulação</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container simulacao">
        <h1>Sucesso na Simulação</h1>

        <?php
        // Recebe os parâmetros da simulação
        $nomeComposteira = isset($_GET['nomeComposteira']) ? $_GET['nomeComposteira'] : '';
        $temperatura = isset($_GET['temperatura']) ? $_GET['temperatura'] : '';
        $umidade = isset($_GET['umidade']) ? $_GET['umidade'] : '';
        $materiais = isset($_GET['materiais']) ? $_GET['materiais'] : '';

        // Exibe a mensagem e os dados da composteira
        if (!empty($nomeComposteira)) {
            echo "<p>Composteira: $nomeComposteira</p>";
        }
        if (!empty($temperatura)) {
            echo "<p>Temperatura: $temperatura</p>";
        }
        if (!empty($umidade)) {
            echo "<p>Umidade: $umidade</p>";
        }
        if (!empty($materiais)) {
            echo "<p>Materiais: $materiais</p>";
        }
        ?>
        
        <a href="index.php">Voltar</a>
    </div>
</body>
</html>
