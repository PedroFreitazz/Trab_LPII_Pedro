<!DOCTYPE html>
<html>
<head>
	<!DOCTYPE html>
<html>
  <head>
    <title>Calculadora de IMC</title>
  </head>
  <body>
    <h1>Calculadora de IMC</h1>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
      <label for="peso">Peso (em kg):</label>
      <input type="text" name="peso" id="peso"><br><br>
      <label for="altura">Altura (em metros):</label>
      <input type="text" name="altura" id="altura"><br><br>
      <input type="submit" name="enviar" value="Enviar">
      <input type="reset" name="limpar" value="Limpar">
    </form>

    <?php
      if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $peso = $_POST["peso"];
        $altura = $_POST["altura"];

        if (!empty($peso) && !empty($altura)) {
          $imc = $peso / ($altura * $altura);
          $classificacao = '';

          if ($imc < 16) {
            $classificacao = 'Magreza grave';
          } elseif ($imc >= 16 && $imc < 17)  {
            $classificacao = 'Magreza moderada';
          } elseif ($imc >= 17 && $imc < 18.5) {
            $classificacao = 'Magreza leve';
          } elseif ($imc >= 18.5 && $imc < 25) {
            $classificacao = 'Saudável';
          } elseif ($imc >= 25 && $imc < 30) {
            $classificacao = 'Sobrepeso';
          } elseif ($imc >= 30 && $imc < 35) {
            $classificacao = 'Obesidade grau I';
          } elseif ($imc >= 35 && $imc < 40) {
            $classificacao = 'Obesidade grau II';
          } elseif ($imc >= 40) {
            $classificacao = 'Obesidade grau III';
          }

          echo "<p>Seu IMC é: " . round($imc, 2) . "</p>";
          echo "<p>Sua classificação é: " . $classificacao . "</p>";
        }
      }
    ?>
  </body>
</html>
