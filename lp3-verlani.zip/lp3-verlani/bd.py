meudicio = {"gato":12, "cachorro":6, "coelho":23}
meudicio["pato"]= meudicio["cachorro"] + meudicio["gato"]
print(meudicio)
