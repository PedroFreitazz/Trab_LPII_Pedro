# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'listar_dados.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(629, 683)
        MainWindow.setStyleSheet(u"background-color: rgb(60, 187, 255);")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.label = QLabel(self.centralwidget)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(190, -20, 261, 61))
        font = QFont()
        font.setPointSize(15)
        self.label.setFont(font)
        self.tableWidget = QTableWidget(self.centralwidget)
        if (self.tableWidget.columnCount() < 4):
            self.tableWidget.setColumnCount(4)
        font1 = QFont()
        font1.setPointSize(11)
        font1.setBold(True)
        font1.setWeight(75)
        __qtablewidgetitem = QTableWidgetItem()
        __qtablewidgetitem.setFont(font1);
        self.tableWidget.setHorizontalHeaderItem(0, __qtablewidgetitem)
        font2 = QFont()
        font2.setPointSize(12)
        font2.setBold(True)
        font2.setWeight(75)
        __qtablewidgetitem1 = QTableWidgetItem()
        __qtablewidgetitem1.setFont(font2);
        self.tableWidget.setHorizontalHeaderItem(1, __qtablewidgetitem1)
        __qtablewidgetitem2 = QTableWidgetItem()
        __qtablewidgetitem2.setFont(font1);
        self.tableWidget.setHorizontalHeaderItem(2, __qtablewidgetitem2)
        __qtablewidgetitem3 = QTableWidgetItem()
        __qtablewidgetitem3.setText(u"CATEGORIA");
        __qtablewidgetitem3.setFont(font1);
        self.tableWidget.setHorizontalHeaderItem(3, __qtablewidgetitem3)
        self.tableWidget.setObjectName(u"tableWidget")
        self.tableWidget.setGeometry(QRect(10, 30, 601, 501))
        self.tableWidget.setMinimumSize(QSize(511, 501))
        font3 = QFont()
        font3.setPointSize(10)
        font3.setBold(False)
        font3.setWeight(50)
        self.tableWidget.setFont(font3)
        self.tableWidget.setStyleSheet(u"background-color: rgb(231, 231, 231);")
        self.tableWidget.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self.tableWidget.setShowGrid(True)
        self.tableWidget.setGridStyle(Qt.NoPen)
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(4)
        self.tableWidget.horizontalHeader().setCascadingSectionResizes(True)
        self.tableWidget.horizontalHeader().setMinimumSectionSize(62)
        self.tableWidget.horizontalHeader().setDefaultSectionSize(144)
        self.pushButton = QPushButton(self.centralwidget)
        self.pushButton.setObjectName(u"pushButton")
        self.pushButton.setGeometry(QRect(440, 600, 151, 41))
        self.pushButton.setFont(font)
        self.pushButton.setStyleSheet(u"background-color: rgb(0, 255, 127);")
        self.btexcluir = QPushButton(self.centralwidget)
        self.btexcluir.setObjectName(u"btexcluir")
        self.btexcluir.setGeometry(QRect(230, 600, 141, 41))
        self.btexcluir.setFont(font)
        self.btexcluir.setStyleSheet(u"background-color: rgb(255, 85, 0);")
        self.bteditar = QPushButton(self.centralwidget)
        self.bteditar.setObjectName(u"bteditar")
        self.bteditar.setGeometry(QRect(20, 600, 121, 41))
        self.bteditar.setFont(font)
        self.bteditar.setStyleSheet(u"background-color: rgb(255, 255, 127);")
        self.lepesq = QLineEdit(self.centralwidget)
        self.lepesq.setObjectName(u"lepesq")
        self.lepesq.setGeometry(QRect(110, 540, 381, 31))
        self.lepesq.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.label_2 = QLabel(self.centralwidget)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(10, 540, 101, 21))
        font4 = QFont()
        font4.setPointSize(12)
        self.label_2.setFont(font4)
        self.btpesq = QPushButton(self.centralwidget)
        self.btpesq.setObjectName(u"btpesq")
        self.btpesq.setGeometry(QRect(500, 540, 91, 31))
        self.btpesq.setFont(font4)
        self.btpesq.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-width:2px;")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 629, 26))
        MainWindow.setMenuBar(self.menubar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.label.setText(QCoreApplication.translate("MainWindow", u"Lista de Produtos", None))
        ___qtablewidgetitem = self.tableWidget.horizontalHeaderItem(0)
        ___qtablewidgetitem.setText(QCoreApplication.translate("MainWindow", u"C\u00d3DIGO", None));
        ___qtablewidgetitem1 = self.tableWidget.horizontalHeaderItem(1)
        ___qtablewidgetitem1.setText(QCoreApplication.translate("MainWindow", u"PRODUTO", None));
        ___qtablewidgetitem2 = self.tableWidget.horizontalHeaderItem(2)
        ___qtablewidgetitem2.setText(QCoreApplication.translate("MainWindow", u"PRE\u00c7O", None));
        self.pushButton.setText(QCoreApplication.translate("MainWindow", u"Gerar PDF", None))
        self.btexcluir.setText(QCoreApplication.translate("MainWindow", u"Excluir", None))
        self.bteditar.setText(QCoreApplication.translate("MainWindow", u"Editar", None))
        self.label_2.setText(QCoreApplication.translate("MainWindow", u"Pesquisar:", None))
        self.btpesq.setText(QCoreApplication.translate("MainWindow", u"OK", None))
    # retranslateUi

