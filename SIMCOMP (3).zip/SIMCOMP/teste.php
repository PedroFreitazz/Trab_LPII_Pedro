<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
    }
    #menu {
      background-color: #333;
      color: white;
      padding: 15px;
      text-align: center;
    }
    #menu a {
      color: white;
      text-decoration: none;
      margin: 0 15px;
    }
    #menu a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div id="menu">
    <a href="#pagina1">Página 1</a>
    <a href="#pagina2">Página 2</a>
    <a href="#pagina3">Página 3</a>
  </div>

  <!-- Conteúdo das páginas -->
  <div id="pagina1">
    <h1>Página 1</h1>
    <p>Conteúdo da página 1.</p>
  </div>

  <div id="pagina2">
    <h1>Página 2</h1>
    <p>Conteúdo da página 2.</p>
  </div>

  <div id="pagina3">
    <h1>Página 3</h1>
    <p>Conteúdo da página 3.</p>
  </div>
</body>
</html>
