<?php
include_once "conecta.php";

$sql = "SELECT * FROM area";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  echo "<table>";
  echo "<tr><th>Nome</th><th>Editar</th><th>Excluir</th></tr>";
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['nome'] . "</td>";
    echo "<td><a href='editar_area.php?id=" . $row['id'] . "'>Editar</a></td>";
    echo "<td><a href='excluir_area.php?id=" . $row['id'] . "' onclick='return confirm(\"Tem certeza que deseja excluir esta área?\")'>Excluir</a></td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  echo "Nenhuma área encontrada.";
}

mysqli_close($conn);
?>
