package com.example.sqlitebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class cadastro extends AppCompatActivity {

    TextView login2, senha2, reserva;
    Button cadastrar2;
    DBHelper sql;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        login2 = findViewById(R.id.login2);
        senha2 = findViewById(R.id.senha2);
        reserva = findViewById(R.id.reserva);
        cadastrar2 = findViewById(R.id.cadastrar2);

        sql = new DBHelper(this);

        cadastrar2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String login_novo = login2.getText().toString().trim();
                String senha_nova = senha2.getText().toString().trim();
                String reserva_nova = reserva.getText().toString().trim();

                if (login_novo.isEmpty()){
                    Toast.makeText(cadastro.this, "Insira um usuário", Toast.LENGTH_SHORT).show();
                }
                if (senha_nova.isEmpty()){
                    Toast.makeText(cadastro.this, "Insira uma senha", Toast.LENGTH_SHORT).show();
                }
                if (reserva_nova.isEmpty()){
                    Toast.makeText(cadastro.this, "Reinsira uma senha", Toast.LENGTH_SHORT).show();
                } else if (senha_nova.isEmpty() || reserva_nova.isEmpty()) {
                    Toast.makeText(cadastro.this, "Insira ou Reinsira uma senha", Toast.LENGTH_SHORT).show();
                } else if (!senha_nova.equals(reserva_nova)) {
                    Toast.makeText(cadastro.this, "As senhas não são iguais", Toast.LENGTH_SHORT).show();
                }
                else {
                    long resultado = sql.Insert(login_novo, senha_nova);
                    if (resultado > 0){
                        Toast.makeText(cadastro.this, "Usuário cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
                        Intent i = getIntent();
                        i.putExtra("username", login_novo);
                        setResult(1,i);
                        finish();
                    }
                }
            }
        });
    }
}