<?php
include_once("conecta.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $umidade = $_POST['umidade'];
    $temperatura = $_POST['temperatura'];
    $tempo = $_POST['tempo'];  // Correção do nome do campo

    // Verifica se a conexão foi bem-sucedida
    if ($conn) {
        $sql = "INSERT INTO Composteira (Nome, Umidade, Temperatura, Tempo_Compostagem) 
                VALUES ('$nome', '$umidade', '$temperatura', '$tempo')";

        if ($conn->query($sql) === TRUE) {
            echo "Dados salvos com sucesso.";
        } else {
            echo "Erro ao salvar os dados: " . $conn->error;
        }
        $conn->close(); // Feche a conexão após o uso
    } else {
        echo "Erro na conexão com o banco de dados.";
    }
}
?>
