from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox

def exibir_mensagem():
    dado_lido = janela.lenome.text()
    print(dado_lido)
    janela.lenome.setText("")
    if dado_lido=="":
        QMessageBox.about(janela,"Nome","Nenum nome reconhecido")
    else:
        QMessageBox.about(janela,"alerta","O nome foi registrado, olá " +dado_lido)
    #Idade
    dado_lido2 = janela.leidade.text()
    #Confere Idade se n estiver vazio
    if dado_lido2=="":
        QMessageBox.about(janela,"Idade:", "Idade Vazia")
    else:
        QMessageBox.about(janela,"Idade:","Você tem: "+dado_lido2)
def fechar_tela():
    result = QMessageBox.question(janela, "Saindo do sistema", "Deseja mesmo sair do sistema?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        janela.close()

def listar_dados():
    dado_lido = janela.lenome.text()
    if dado_lido=="":
        QMessageBox.about(janela,"Nome","Nenum nome reconhecido")
    else:
        QMessageBox.about(janela,"alerta","O nome foi registrado, olá " +dado_lido)
    #Idade
    dado_lido2 = janela.leidade.text()
#Confere Idade se n estiver vazio
    if dado_lido2=="":
        QMessageBox.about(janela,"Idade:", "Idade Vazia")
    else:
        QMessageBox.about(janela,"Idade:","Você tem: "+dado_lido2)
    dado_lido3=""
    if janela.rb1.isChecked():
        dado_lido3="M"
    elif janela.rb2.isChecked():
        dado_lido3= "F"
    else:
        dado_lido3="ND"
    
    dado_lido4=janela.cbnivel.currentText()
    janela.lista.addItem(dado_lido)
    janela.lista.addItem(dado_lido2)
    janela.lista.addItem(dado_lido3)
    janela.lista.addItem(dado_lido4)
def deletar():
    result = QMessageBox.question(janela, "Excluir Itens", "Deseja excluir todos os itens da Lista?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        janela.lista.clear()
def contar_itens():
    valor = janela.lista.count()
    janela.lbconta.setText(str(valor)) 
def ordenar():
    janela.lista.sortItems()
#programa principal
app=QtWidgets.QApplication([])
janela=uic.loadUi("caixa_mensagem_aula3.ui")
janela.BTverificar.clicked.connect(exibir_mensagem)
janela.show()
janela.btfechar.clicked.connect(fechar_tela)
janela.btadicionar.clicked.connect(listar_dados)
janela.btexcluir.clicked.connect(deletar)
janela.btcontar.clicked.connect(contar_itens)
janela.btordenar.clicked.connect(ordenar)
app.exec()