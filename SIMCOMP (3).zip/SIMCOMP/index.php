<!DOCTYPE html>
<html>
<head>
  <title>Página Inicial</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body class="index">
  <div class="logo">
    <img src="img/LOGOSIMCOMP.png" alt="Logo">
  </div>
  <div class="container index">
    <h2>Bem-Vindo</h2>
    <ul>
      <li><a href="criarcomp.php">Criar Composteira</a></li>
      <li><a href="cadcategoria.php">Cadastrar Categoria</a></li>
      <li><a href="cadmaterial.php">Cadastrar Material</a></li>
      <li><a href="regras.php">Definir Regras</a></li>

    </ul>
  </div>
</body>
</html>
