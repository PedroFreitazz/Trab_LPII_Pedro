<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Formulário de Autenticação</title>
  </head>
  <body>
    <h1>Formulário de Autenticação</h1>
    <form method="post" action="autenticar.php">
      <label for="nome">Nome do Usuário:</label>
      <input type="text" id="nome" name="nome"><br>
      <label for="senha">Senha:</label>
      <input type="password" id="senha" name="senha"><br>
      <input type="submit" value="Enviar">
      <input type="reset" value="Limpar">
    </form>
  </body>
</html>
