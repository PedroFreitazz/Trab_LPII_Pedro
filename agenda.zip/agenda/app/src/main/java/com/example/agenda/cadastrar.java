package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cadastrar extends AppCompatActivity {
    EditText cad_nome,cad_tel,cad_email;

    Button cadsalvar;
    dbhelper sql;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);
        cad_nome=findViewById(R.id.cad_nome);
        cad_tel=findViewById(R.id.cad_tel);
        cad_email=findViewById(R.id.cad_email);
        cadsalvar=findViewById(R.id.cad_salvar);
        sql= new dbhelper(this);
        cadsalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String lognome = cad_nome.getText().toString().trim();
                String logtel = cad_tel.getText().toString().trim();
                String logmail= cad_email.getText().toString().trim();
                if (lognome.isEmpty()){
                    Toast.makeText(cadastrar.this,"Insira um nome",Toast.LENGTH_SHORT).show();
                }
                if (logtel.isEmpty()){
                    Toast.makeText(cadastrar.this,"Insira seu telefone",
                            Toast.LENGTH_SHORT).show();
                }
                if(logmail.isEmpty()){
                    Toast.makeText(cadastrar.this,"Insira seu email",Toast.LENGTH_SHORT).show();
                }
                else{
                    long resultado= sql.Insert(lognome,logtel,logmail);
                    if(resultado > 0){
                        Toast.makeText(cadastrar.this, "Cadastro sucesso", Toast.LENGTH_SHORT).show();
                        Intent i =getIntent();
                        i.putExtra("username",lognome);
                        setResult(1,i);
                        finish();
                    }
        }}});
    }
}