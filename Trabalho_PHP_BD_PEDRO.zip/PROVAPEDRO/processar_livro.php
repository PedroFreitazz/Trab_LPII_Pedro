<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $titulo = $_POST["titulo"];
  $autor = $_POST["autor"];
  $id_area = $_POST["id_area"];
  $status = "disponivel"; 
  
  include_once "conecta.php";

  $sql = "INSERT INTO livro (titulo, autor, id_area, status) VALUES ('$titulo', '$autor', $id_area, 1)";

  if (mysqli_query($conn, $sql)) {
    echo "Livro cadastrado com sucesso!";
  } else {
    echo "Erro ao cadastrar o livro: " . mysqli_error($conn);
  }

  mysqli_close($conn);
}
?>
