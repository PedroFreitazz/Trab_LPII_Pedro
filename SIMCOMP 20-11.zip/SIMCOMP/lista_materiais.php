<?php
include_once "conecta.php";

$query = "SELECT m.Material_ID, m.Nome, c.Nome as Categoria
          FROM Material m
          INNER JOIN Categoria c ON m.fk_Categoria_Categoria_ID = c.Categoria_ID";
$resultado = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista Materiais</title>
    <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="container">
        <h1>Lista de Materiais</h1>

        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Categoria</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($resultado)) {
                    echo "<tr>";
                    echo "<td>{$row['Nome']}</td>";
                    echo "<td>{$row['Categoria']}</td>";
                    echo "<td class='actions'>";
                    echo "<a href='editar_material.php?id={$row['Material_ID']}'>Editar</a>";
                    echo "<a href='excluir_material.php?id={$row['Material_ID']}' onclick='return confirm(\"Tem certeza que deseja excluir?\")'>Excluir</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
