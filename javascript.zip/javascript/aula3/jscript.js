function corFundo(){
    var elemento = document.getElementById("noticia");
    elemento.style.backgroundColor = "beige";
    elemento.style.width = "190px";
    window.alert(elemento);
} 
function diminuirNoticia(){
    var elemento = document.getElementById("conteudo1");
    elemento.style.fontSize = "10px";
    window.alert(elemento);
}
function aumentarNoticia(){
    var elemento = document.getElementById("conteudo2");
    elemento.style.fontSize = "40px";
    window.alert(elemento);
}
function estilizarPagina(){
    var elemento1 = document.getElementById("titulo");
    elemento1.style.background = "#DB7093";
    elemento1.style.width = "295px";
    elemento1.style.textDecoration = "underline";
    elemento1.style.borderRadius = "10px";
    elemento1.style.padding = "14px";
    elemento1.style.color = "white";
    elemento1.style.fontFamily = "system-ui";

    var elemento2 = document.getElementById("noticia");
    elemento2.style.textDecoration = "underline";   
    elemento2.style.fontSize = "20px";

    var elemento3 = document.getElementById("lista");
    elemento3.style.background = "#F5DEB3";
    elemento3.style.width = "200px";
    elemento3.style.height = "50px";
    elemento3.style.margin = "14px";
    elemento3.style.borderRadius = "6px";
    
}

function tituloGrande(){
    var elemento5 = document.getElementById("titulo2");
    elemento5.style.fontSize = "65px";
}

function tituloMedio(){
    var elemento5 = document.getElementById("titulo2");
    elemento5.style.fontSize = "45px";
}

function tituloPequeno(){
    var elemento5 = document.getElementById("titulo2");
    elemento5.style.fontSize = "20px";
}

function estilizarTagName(){
    var elemento6 = document.getElementsByTagName("div");
    elemento6.style.backgroundColor = "#F5DEB3";

}

function alterarP(){
    var elemento7 = document.getElementById("noticia3");
    elemento7.innerHTML = "Mudei o parágrafo!";
}

function acrescentaP(){
    var elemento8 = document.getElementById("titulo3");
    elemento8.innerHTML = "";
}