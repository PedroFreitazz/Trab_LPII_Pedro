<?php
$host = "localhost";
$user ="root";
$password ="";
$dbname ="escola";

$conexao = mysqli_connect($host, $user, $password, $dbname);
echo "Cadastro realizado com sucesso!";

if (!$conexao) {
	die("Erro na conexão: " . mysqli_connect_error());
}

?>
