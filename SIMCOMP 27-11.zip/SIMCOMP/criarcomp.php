<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Composteira</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<a class="voltar"  href="index.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
    <div class="container">
        <h1>Composteira</h1>
        <form action="salvar_dados.php" method="POST">
            <div class="form-group">
                <label for="nome">Nome da Composteira:</label>
                <input type="text" id="nome" name="nome" placeholder="Digite o nome da composteira">
            </div>
            <div class="form-group">
                <label for="umidade">Umidade:</label>
                <input type="text" id="umidade" name ="umidade" placeholder="Digite a umidade da composteira">
            </div>
            <div class="form-group">
                <label for="temperatura">Temperatura:</label>
                <input type="text" id="temperatura" name="temperatura" placeholder="Digite a temperatura da composteira">
            </div>
            <div class="form-group">
    <label for="materiais">Selecione os Materiais:
        (Pressione CTRL para a seleção 2 ou mais materiais)</label>
    <select id="materiais" name="materiais[]" multiple class="custom-select">
        <?php
        include_once("conecta.php");
        $sql = "SELECT Material_ID, Nome FROM Material";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row["Material_ID"] . "'>" . $row["Nome"] . "</option>";
            }
        } else {
            echo "Nenhum material encontrado.";
        }
        $conn->close();
        ?>
    </select>
</div>

            <div class="form-group">
                <label for="tempo">Tempo De Compostagem (em dias):</label>
                <select id="tempo" name="tempo">
                    <option value="1">10 dias</option>
                    <option value="2">20 dias</option>
                    <option value="3">30 dias</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit">Criar</button>
            </div>
        </form>
        <a href="listar_composteira.php" class="listar-button">Composteiras Já Registradas</a>

    </div>
</body>
</html>
