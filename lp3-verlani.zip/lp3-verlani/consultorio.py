from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox
from cmath import sqrt
pacientes=[]
def adiciona():
    nome=janela.LEnome.text()
    if nome=="":
        QMessageBox.about(janela,"Nome","Nenum nome reconhecido")
    pacientes.append(nome)#adiciona no vetor
    janela.lwpac.addItem(nome)
def fechar_tela():
    result = QMessageBox.question(janela, "Saindo do sistema", "Deseja mesmo sair do sistema?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        janela.close()
def deletar():
    janela.lwpac.clear()
    janela.LIaten.clear()
def mostra_dados():
    tam = len(pacientes) #lê o tamanho do vetor
    for i in range(tam):
        janela.lwpac.addItem(pacientes[i])
def transferir():
    if janela.lwpac.count()<1:
        temp=janela.lwpac.currentItem().text()
        janela.lwpac.takeItem(janela.lwpac.currentRow())
        janela.LIaten.addItem(temp)
    else:
        sair=QMessageBox.question(janela, "Retirar status do paciente", "Deseja mesmo alterar o estado deste paciente?", QMessageBox.Yes, QMessageBox.No)
        if sair==QMessageBox.Yes:
            janela.LIaten.clear()
            temp=janela.lwpac.currentItem().text()
            janela.lwpac.takeItem(janela.lwpac.currentRow())
            janela.LIaten.addItem(temp)
app=QtWidgets.QApplication([])
janela=uic.loadUi("consultorio.ui")
janela.show()
janela.PBadicionar.clicked.connect(adiciona)
janela.btfechar.clicked.connect(fechar_tela)
janela.mostrarpac.clicked.connect(mostra_dados)
janela.bttransf.clicked.connect(transferir)
app.exec()