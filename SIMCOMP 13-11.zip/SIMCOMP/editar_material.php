<?php
include_once "conecta.php";

if (isset($_GET['id'])) {
    $material_id = $_GET['id'];

    // Consulta para obter os detalhes do material específico
    $query = "SELECT * FROM Material WHERE Material_ID = $material_id";
    $resultado = mysqli_query($conn, $query);

    if (!$resultado) {
        die("Erro na consulta: " . mysqli_error($conn));
    }

    $material = mysqli_fetch_assoc($resultado);

    // Obter todas as categorias para o dropdown
    $queryCategorias = "SELECT * FROM Categoria";
    $resultadoCategorias = mysqli_query($conn, $queryCategorias);

    if (!$resultadoCategorias) {
        die("Erro na consulta de categorias: " . mysqli_error($conn));
    }
} else {
    die("ID do material não fornecido.");
}

// Processar o formulário de edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $categoria = $_POST['categoria'];

    // Atualizar os detalhes do material no banco de dados
    $atualizar_query = "UPDATE Material SET Nome = '$nome', fk_Categoria_Categoria_ID = $categoria WHERE Material_ID = $material_id";
    $atualizar_resultado = mysqli_query($conn, $atualizar_query);

    if (!$atualizar_resultado) {
        die("Erro na atualização: " . mysqli_error($conn));
    }

    // Redirecionar de volta para a lista de materiais após a edição
    header("Location: lista_materiais.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Mesmo cabeçalho do arquivo anterior -->
</head>
<body>
    <div class="container">
        <h1>Editar Material</h1>

        <form method="post">
            <div class="form-group">
                <label for="nome">Nome do Material:</label>
                <input type="text" id="nome" name="nome" value="<?php echo $material['Nome']; ?>" required>
            </div>

            <div class="form-group">
                <label for="categoria">Categoria:</label>
                <select id="categoria" name="categoria" required>
                    <?php
                    while ($rowCategoria = mysqli_fetch_assoc($resultadoCategorias)) {
                        $selected = ($rowCategoria['Categoria_ID'] == $material['fk_Categoria_Categoria_ID']) ? 'selected' : '';
                        echo "<option value='{$rowCategoria['Categoria_ID']}' $selected>{$rowCategoria['Nome']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <button type="submit">Salvar</button>
            </div>
        </form>
    </div>
</body>
</html>
