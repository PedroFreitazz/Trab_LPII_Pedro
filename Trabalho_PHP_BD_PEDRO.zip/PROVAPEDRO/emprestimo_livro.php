<!DOCTYPE html>
<html>
<head>
  <title>Empréstimo de Livros</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <h1>Empréstimo de Livros</h1>

  <?php
  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $aluno = $_POST['aluno'];
    $livros = isset($_POST['livros']) ? $_POST['livros'] : [];
    $dataEntrega = $_POST['data_entrega'];

     include_once "conecta.php";


    $status = "emprestado";

   $sql = "INSERT INTO reserva (id_livro, matricula, data_retirada, data_entrega, status) VALUES ";

    foreach ($livros as $livro) {
      $sql .= "('$livro', '$aluno', NOW(), '$dataEntrega', '$status'), ";
    }

    $sql = rtrim($sql, ", ");

    if (mysqli_query($conn, $sql)) {
      $sql_update = "UPDATE livro SET status = 'emprestado' WHERE id IN (" . implode(",", $livros) . ")";
      mysqli_query($conn, $sql_update);

      echo "Empréstimo realizado com sucesso!";
    } else {
      echo "Erro ao realizar o empréstimo: " . mysqli_error($conn);
    }

  }
  ?>

  <?php
 include_once "conecta.php";

  $sql_alunos = "SELECT matricula, nome FROM aluno";
  $result_alunos = mysqli_query($conn, $sql_alunos);
  $alunos = mysqli_fetch_all($result_alunos, MYSQLI_ASSOC);

  // Consulta para obter a lista de livros disponíveis
  $sql_livros = "SELECT id, titulo FROM livro WHERE status = 1";
  $result_livros = mysqli_query($conn, $sql_livros);
  $livros = mysqli_fetch_all($result_livros, MYSQLI_ASSOC);

  mysqli_close($conn);
  ?>

  <form method="POST" action="<?php echo $_SERVER['PHP_SELF']; ?>">
    <label for="aluno">Aluno:</label>
    <select id="aluno" name="aluno" required>
      <?php foreach ($alunos as $aluno): ?>
        <option value="<?php echo $aluno['matricula']; ?>"><?php echo $aluno['nome']; ?></option>
      <?php endforeach; ?>
    </select><br><br>

    <label>Livros Disponíveis:</label><br>
    <?php foreach ($livros as $livro): ?>
      <input type="checkbox" name="livros[]" value="<?php echo $livro['id']; ?>">
      <?php echo isset($livro['titulo']) ? $livro['titulo'] : 'Título indisponível'; ?><br>
    <?php endforeach; ?><br>
    <label for="data_entrega">Data de Entrega:</label>
    <input type="date" id="data_entrega" name="data_entrega" required><br><br>

    <input type="submit" value="Realizar Empréstimo">
  </form>
  <li><a href="index.php">Voltar à Página Inicial</a></li>
</body>
</html>
