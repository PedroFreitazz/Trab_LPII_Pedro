<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categoria</title>
    <link rel="stylesheet" href="style.css">
</head>
<a class="voltar"  href="index.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
<body>
    <div class="container">
        <h1>Categoria</h1>
        <form action="inserir_categoria.php" method="POST">           
            <div class="form-group">
                <label for="nome">Nome da Categoria:</label>
                <input type="text" id="nome" name="nome" placeholder="Digite o nome da categoria">
            </div>
            <div class="form-group">
                <label for="impacto">Impacto na Composteira:</label>
                <select id="impacto" name="impacto">
                    <option value="1">Impróprio</option>
                    <option value="2">Próprio</option>
                </select>
            </div>
            <div class="form-group">
                <button type="submit">Salvar</button>
            </div>
        </form>
    </div>
</body>
</html>
