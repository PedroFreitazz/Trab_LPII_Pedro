<?php
include_once 'conecta.php';

$nome= $_POST['nome'];
$idade= $_POST['idade'];
$curso= $_POST['curso'];

$sql = "INSERTO INTO alunos (nome,idade,curso) values('$nome','$idade','$curso')";

$res =mysqli_query($conexao,$sql)


?>