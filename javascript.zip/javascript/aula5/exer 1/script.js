window.onload = function(){
    var elemento = document.getElementById("bloco");
    elemento.addEventListener("mouseover", moveSobre);
    elemento.addEventListener("mouseout", moveParaFora);
    
    }
    function moveSobre(){
        this.innerHTML = "Conculído";
    }
    function moveParaFora(){
        this.innerHTML = "1° Exercício";
    }