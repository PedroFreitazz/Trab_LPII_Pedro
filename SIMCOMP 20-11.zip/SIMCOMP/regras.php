<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Regra</title>
    <link rel="stylesheet" href="style.css">
</head>
<a class="voltar"  href="index.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
<body>
<div class="container">
    <h1>Cadastro de Regra</h1>

    <form action="inserir_regra.php" method="POST">
        <div class="form-group">
            <h2>Temperatura</h2>
            <label for="Temp_min">Valor Mínimo:</label>
            <input type="text" id="Temp_min" name="Temp_min" required>

            <label for="Temp_max">Valor Máximo:</label>
            <input type="text" id="Temp_max" name="Temp_max" required>
        </div>

        <div class="form-group">
            <h2>Umidade</h2>
            <label for="Umid_min">Valor Mínimo:</label>
            <input type="text" id="Umid_min" name="Umid_min" required>

            <label for="Umid_max">Valor Máximo:</label>
            <input type="text" id="Umid_max" name="Umid_max" required>
        </div>

        <div class="form-group">
            <label for="Composteira_id">Selecione a Composteira:</label>
            <select id="Composteira_id" name="Composteira_id">
                <?php
                    include_once("conecta.php");  // Certifique-se de ter a conexão correta aqui
                    $sql = "SELECT Composteira_ID, Nome FROM Composteira";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row["Composteira_ID"] . "'>" . $row["Nome"] . "</option>";
                        }
                    } else {
                        echo "Nenhuma composteira encontrada.";
                    }
                    $conn->close();
                ?>
            </select>
        </div>

        <div class="form-group">
            <button type="submit">Cadastrar Regra</button>
        </div>
        <a href="listar_regra.php" class="listar-button">Regras Já Registradas</a>

    </form>
</div>
</body>
</html>
