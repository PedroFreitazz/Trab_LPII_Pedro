    window.onload = function(){
    var bloco = document.getElementById("bloco");
    bloco.style.width = '200px';
    bloco.style.height= '50px';
    bloco.style.border = '2px solid black';
    bloco.style.fontFamily = 'gothic';
    bloco.style.padding = '40px';
    bloco.style.backgroundColor = 'red';
    bloco.style.color ='black';
    

}
