<!DOCTYPE html>
<html>
<head>
    <title>Contato - Loja de Artigos Musicais</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>Contato</h1>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Início</a></li>
            <li><a href="produtos.php">Produtos</a></li>
            <li><a href="contato.php">Contato</a></li>
            <li><a href="carrinho.php">Carrinho</a></li> <!-- Adicione esta linha -->

        </ul>
    </nav>

    <section class="main-content">
        <h2>Entre em Contato Conosco</h2>
        <p>Se você tiver alguma dúvida ou sugestão, entre em contato através do formulário abaixo:</p>

        <form action="enviar_contato.php" method="post">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" required>

            <label for="mensagem">Mensagem:</label>
            <textarea id="mensagem" name="mensagem" rows="4" required></textarea>

            <button type="submit">Enviar</button>
        </form>
    </section>

    <footer>
        <p>&copy; 2023 Pfmusic</p>
    </footer>
</body>
</html>
