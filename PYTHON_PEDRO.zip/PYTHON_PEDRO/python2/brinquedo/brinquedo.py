#importar bibliotecas:
from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox

 


dicionario={}

def adicionar():
    nome = janela.lenome.text()
    idade = janela.sbidade.text()
    if nome == "" or idade == "":
        QMessageBox.information(janela, "Information", "Por favor, adicione os dados!")
    else:
        dicionario.update[""]= nome
        dicionario.update[""]= idade

        nome.setText("")
        idade.setText("")

def listar_dados():
    


def limpar():
    
    janela.lwcampo.setText("")


def fechar_tela():
    result = QMessageBox.question(janela, "Saindo do sistema", "Realmente deseja sair?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.yes:
        janela.close()


#programa principal
app=QtWidgets.QApplication([])
janela=uic.loadUi("brinquedo.ui")
janela.pbadicionar.clicked.connect(adicionar)
janela.pblistar.clicked.connect(listar_dados)
janela.pblimpar.clicked.connect(limpar)
janela.pbfechar.clicked.connect(fechar_tela)
janela.show()
app.exec()