<?php
include_once("conecta.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST["nome"];
    $categoria_id = $_POST["categoria"];

    $sql = "INSERT INTO Material (Nome, fk_Categoria_Categoria_ID) VALUES ('$nome', $categoria_id)";

    if ($conn->query($sql) === TRUE) {
        echo "Material cadastrado com sucesso.";
    } else {
        echo "Erro ao cadastrar o material: " . $conn->error;
    }
}

$conn->close();
?>
