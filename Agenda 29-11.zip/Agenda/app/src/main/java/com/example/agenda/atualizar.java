package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class atualizar extends AppCompatActivity {
    EditText actualid, atual_nome,atual_tel,atual_email;
    Button atualizar;
    dbhelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atualizar);
        actualid=findViewById(R.id.actualid);
        atual_nome=findViewById(R.id.atual_nome);
        atual_tel=findViewById(R.id.atual_tel);
        atual_email=findViewById(R.id.atual_email);
        atualizar=findViewById(R.id.atualizar);
        db = new dbhelper(this);
        atualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            int id= Integer.parseInt(actualid.getText().toString());
            String nome= atual_nome.getText().toString();
            String telefone= atual_tel.getText().toString();
            String email= atual_email.getText().toString();
            long resultado = db.Update(id,nome,telefone,email);
            if (resultado>0){
                Toast.makeText(atualizar.this, "Dados Atualizados", Toast.LENGTH_SHORT).show();
                }
            else{
                Toast.makeText(atualizar.this, "Erro ao Atualizar", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

}