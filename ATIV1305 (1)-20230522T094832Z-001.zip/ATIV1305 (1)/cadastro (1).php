<!DOCTYPE html>
<html>
<head>
	<title>Escola PF - Cadastro</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<nav>
			<ul>
				<li><a href="index.php">Página Inicial</a></li>
				<li><a href="visualizacao.php">Visualização</a></li>
			</ul>
		</nav>
	</header>
	<main>
		<h1>Cadastro de Aluno</h1>
		<form action="cadastra.php" method="post">
			<label for="nome">Nome:</label>
			<input type="text" name="nome" required>
			<br>
			<label for="idade">Idade:</label>
			<input type="number" name="idade" required>
			<br>
			<label for="curso">Curso:</label>
			<input type="text" name="curso" required>
			<br>
			<input type="submit" value="Cadastrar">
		</form>
	</main>
	<footer>
		<p>&copy; 2023 Minha Escola. Todos os direitos reservados.</p>
	</footer>
</body>
</html>
