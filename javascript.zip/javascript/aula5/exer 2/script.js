window.onload = function(){
    var elemento = document.getElementById("bloco");
    elemento.addEventListener("click", fundoVermelho);
    elemento.addEventListener("click", fundoAzul);
    elemento.addEventListener("click", estilizarBloco);
    
    }
    function fundoVermelho(){
        var bnt1 = document.getElementById("b1");
        bnt1.style.background = "red";
    }
    function fundoAzul(){
        var bnt2 = document.getElementById("b2");
        bnt2.style.background = "blue";
    }
    function estilizarBloco(){
        var bnt3 = document.getElementById("b3");
        bnt3.style.background = "red";
    }