from PyQt5 import uic, QtWidgets
from PyQt5.QtWidgets import QMessageBox
import mysql.connector

banco = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="",
    database="sistema"
)

def inserir_dados():
    linha1 = formulario.lineEdit_2.text()
    linha2 = formulario.lineEdit_3.text()

    if not linha1 or not linha2:
        QMessageBox.warning(formulario, "Aviso", "Preencha todos os campos.")
        return

    try:
        float(linha2)
    except ValueError:
        QMessageBox.warning(formulario, "Aviso", "O valor deve ser numérico.")
        return

    categoria = ""
    
    if formulario.radioButton_1.isChecked():
        categoria = "Alimentos"
    elif formulario.radioButton_2.isChecked():
        categoria = "Eletrônicos"
    else:
        categoria = "Informática"

    print("Descricao:", linha1)
    print("Valor:", linha2)

    cursor = banco.cursor()
    comando_SQL = "INSERT INTO produtos (descricao,preco,categoria) VALUES (%s,%s,%s)"
    dados = (str(linha1), str(linha2), categoria)
    cursor.execute(comando_SQL, dados)
    banco.commit()
    formulario.lineEdit_2.setText("")
    formulario.lineEdit_3.setText("")

def editar_dados():
    global numero_id

    linha = segunda_tela.tableWidget.currentRow()
    
    cursor = banco.cursor()
    cursor.execute("SELECT id FROM produtos")
    dados_lidos = cursor.fetchall()
    valor_id = dados_lidos[linha][0]
    cursor.execute("SELECT * FROM produtos WHERE id="+ str(valor_id))
    produto = cursor.fetchall()
    tela_editar.show()

    tela_editar.lineEdit.setText(str(produto[0][0]))
    tela_editar.lineEdit_2.setText(str(produto[0][1]))
    tela_editar.lineEdit_3.setText(str(produto[0][2]))
    tela_editar.lineEdit_4.setText(str(produto[0][3]))
    tela_editar.lineEdit_5.setText(str(produto[0][4]))
    numero_id = valor_id

def excluir_dados():
    linha = segunda_tela.tableWidget.currentRow()
    if linha < 0:
        QMessageBox.warning(formulario, "Aviso", "Selecione um item para excluir.")
        return

    result = QMessageBox.question(formulario, "Confirmação", "Deseja mesmo excluir este item?", QMessageBox.Yes | QMessageBox.No)
    if result == QMessageBox.Yes:
        cursor = banco.cursor()
        cursor.execute("SELECT id_produto FROM produtos")
        dados_lidos = cursor.fetchall()
        valor_id = dados_lidos[linha][0]
        cursor.execute("DELETE FROM produtos WHERE id_produto=" + str(valor_id))

        # Atualize a tabela após excluir
        chama_segunda_tela()

def chama_segunda_tela():
    segunda_tela.show()
    cursor = banco.cursor()
    comando_SQL = "SELECT * FROM produtos"
    cursor.execute(comando_SQL)
    dados_lidos = cursor.fetchall()

    segunda_tela.tableWidget.setRowCount(len(dados_lidos))
    segunda_tela.tableWidget.setColumnCount(4)

    for i in range(0, len(dados_lidos)):
        for j in range(0, 4):
            segunda_tela.tableWidget.setItem(i, j, QtWidgets.QTableWidgetItem(str(dados_lidos[i][j])))

def fechar_tela():
    result = QMessageBox.question(formulario, "Saindo do sistema", "Deseja mesmo sair do sistema?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        formulario.close()

app = QtWidgets.QApplication([])
formulario = uic.loadUi("produtos.ui")
segunda_tela = uic.loadUi("listar_dados.ui")
tela_editar = uic.loadUi("menu_editar.ui")

formulario.pushButton.clicked.connect(inserir_dados)
formulario.pushButton_2.clicked.connect(chama_segunda_tela)
formulario.btfechar.clicked.connect(fechar_tela)
segunda_tela.btexcluir.clicked.connect(excluir_dados)
segunda_tela.bteditar.clicked.connect(editar_dados)

formulario.show()
app.exec()
