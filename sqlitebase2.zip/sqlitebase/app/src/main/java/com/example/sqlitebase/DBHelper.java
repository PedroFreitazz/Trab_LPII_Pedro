package com.example.sqlitebase;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DBHelper extends SQLiteOpenHelper {

    private static int versao = 1;
    private static String nomeDB = "base.db";
    String[] sql = {"create table usuarios( id integer, username text, password text, primary key (id autoincrement));"};

    public DBHelper(@Nullable Context context) {
        super(context, nomeDB, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        for (int i = 0; i < sql.length; i++){
            db.execSQL(sql[i]);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        versao++;
        db.execSQL("drop table if exists usuarios");
        onCreate(db);

    }

    public long Insert (String username, String password){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valor = new ContentValues();
        valor.put("username", username);
        valor.put("password", password);
        return db.insert("usuarios", null, valor);
    }

    public long Update (int id, String username, String password){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valor = new ContentValues();
        valor.put("username", username);
        valor.put("password", password);
        return  db.update("usuarios", valor, "id=?", new String[]{String.valueOf(id)});
    }

    public long Delete (int id){
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("usuarios", "id=?", new String[]{String.valueOf(id)});
    }

    @SuppressLint("Range")
   public long Select (String username, String password){
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("select * from usuarios where username=? and password=?", new String[]{username, password} );
        c.moveToFirst();
        if (c.getCount()==1){
           return c.getInt(c.getColumnIndex("id"));
       }
       return -1;
   }

   @SuppressLint("Range")
   public List<Usuarios> selectAll(){
       SQLiteDatabase db = getReadableDatabase();
       Cursor c = db.rawQuery("select * from usuarios", null);
       List<Usuarios> listausuarios = new ArrayList<>();
       c.moveToFirst();

       if (c.getCount() > 0){
           do{
               int id = c.getInt(c.getColumnIndex("id"));
               String username = c.getString(c.getColumnIndex("username"));
               String password = c.getString(c.getColumnIndex("password"));
               listausuarios.add(new Usuarios(id, username, password));
           }
           while (c.moveToNext());
       }
       return listausuarios;
   }
    @SuppressLint("Range")
    public Usuarios selectID(int id){
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("select * from usuarios where id=?", new String[]{String.valueOf(id)});
        c.moveToFirst();

        if (c.getCount() == 1){
            String username = c.getString(c.getColumnIndex("username"));
            String password = c.getString(c.getColumnIndex("password"));

            return new Usuarios(id, username, password);
        }
        return null;

    }}
