<!DOCTYPE html>
<html>
<head>
  <title>Cadastro de Área</title>
  <link rel="stylesheet" type="text/css" href="style.css">

</head>
<li><a href="index.php">Voltar á Pagina Inicial</a></li>

<body>
<div class="h2">

  <h2>Cadastro de Área</h2>
</div>
  <form action="processar_area.php" method="POST">

    <label for="nome">Nome da Área:</label>
    <input type="text" id="nome" name="nome" required>

    <input type="submit" value="Cadastrar Área">
  </form>
</body>
</html>
