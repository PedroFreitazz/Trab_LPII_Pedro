<!DOCTYPE html>
<html>
<head>
    <title>Loja de Artigos Musicais</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
        <h1>PFmusic</h1>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Início</a></li>
            <li><a href="produtos.php">Produtos</a></li>
            <li><a href="contato.php">Contato</a></li>
            <li><a href="carrinho.php">Carrinho</a></li> <!-- Adicione esta linha -->

        </ul>
    </nav>

    <section class="main-content">
        <h2>Bem-vindo à nossa loja!</h2>
        <p>Explore nossa coleção de instrumentos e acessórios musicais.</p>
        <img src="img/james.jpg">
    </section>

    <footer>
        <p>&copy; 2023 Loja de Artigos Musicais</p>
    </footer>
</body>
</html>
