package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class consultar extends AppCompatActivity {
    ListView listacontato;
    Intent i;
    Button con_atualizar,con_deletar;
    List<Contatos> listacontatos2;
    ArrayAdapter<Contatos> adapter;
    int id2;
    String nome2;
    String telefone2;
    String email2;
    static final int CODIGO = 1;
    dbhelper sql;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar);
        con_atualizar=findViewById(R.id.con_atualizar);
        con_deletar=findViewById(R.id.con_deletar);
        listacontato=findViewById(R.id.listacontato);
        i=getIntent();
        sql= new dbhelper(this);
        listacontatos2=new ArrayList<>();
        preencherlista();
        listacontato.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                id2=listacontatos2.get(position).getId();
                nome2=listacontatos2.get(position).getNome();
                telefone2=listacontatos2.get(position).getTel();
                email2=listacontatos2.get(position).getEmail();

            }
        });
        con_atualizar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            Intent i= new Intent(consultar.this, atualizar.class);
            i.putExtra("id",id2);
            i.putExtra("nome",nome2);
            i.putExtra("telefone",telefone2);
            i.putExtra("email",email2);
            startActivityForResult(i,CODIGO);
            }
        });
        con_deletar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long resultado = sql.Delete(id2);
                if (resultado>0){
                    Toast.makeText(consultar.this, "Usuário Apagado", Toast.LENGTH_SHORT).show();
                    preencherlista();
                }
                else{
                    Toast.makeText(consultar.this, "Erro ao Apagar Usuário", Toast.LENGTH_SHORT).show();
                }
            }});
    }
    private  void preencherlista() {
        listacontatos2 = sql.SelectAll();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listacontatos2);
        listacontato.setAdapter(adapter);

    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode == CODIGO && resultCode == RESULT_OK );
        preencherlista();
    }
}