package com.example.sqlitebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class acesso extends AppCompatActivity {
    EditText id_editar,user_editar,pass_editar;
    Button editar, deletar;
    ListView listauser;
    dbhelper db;
    Intent i;
    List<usuarios> listausuarios;
    ArrayAdapter<usuarios> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_acesso);
        id_editar=findViewById(R.id.id_editar);
        user_editar=findViewById(R.id.user_editar);
        pass_editar=findViewById(R.id.pass_editar);
        editar=findViewById(R.id.editar);
        deletar=findViewById(R.id.deletar);
        listauser=findViewById(R.id.listauser);

        db = new dbhelper(this);
        i = getIntent();
        int id= (int) i.getExtras().getLong("id");
        preencherdados(id);
        listausuarios = new ArrayList<>();
        preencherlista();
        listauser.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                id_editar.setText(String.valueOf(listausuarios.get(position).getId()));
                user_editar.setText(String.valueOf(listausuarios.get(position).getUsername()));
                pass_editar.setText(String.valueOf(listausuarios.get(position).getPassword()));

            }
        });
        deletar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                long resultado = db.Delete(Integer.parseInt(id_editar.getText().toString()));
                if (resultado>0){
                    Toast.makeText(acesso.this, "Usuário Apagado", Toast.LENGTH_SHORT).show();
                    preencherlista();
                }
                else{
                    Toast.makeText(acesso.this, "Erro ao Apagar Usuário", Toast.LENGTH_SHORT).show();
                }
            }
        });
        editar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int id = Integer.parseInt(id_editar.getText().toString());
                String username = user_editar.getText().toString();
                String password = pass_editar.getText().toString();

                long resultado = db.Update(id,username,password);
                if (resultado>0){
                    Toast.makeText(acesso.this, "Dados Atualizados", Toast.LENGTH_SHORT).show();
                    preencherlista();
                }
                else{
                    Toast.makeText(acesso.this, "Erro ao Atualizar", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }
    private void preencherdados(int id){
        usuarios U =db.SelectID(id);
        id_editar.setText(String.valueOf(U.id));
        user_editar.setText(String.valueOf(U.username));
        pass_editar.setText(String.valueOf(U.password));
    }
    private  void preencherlista() {
        listausuarios = db.SelectAll();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listausuarios);
        listauser.setAdapter(adapter);

    }

}