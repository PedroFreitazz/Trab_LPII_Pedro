function alterarConteudo() {
    var novoConteudo = prompt('Digite o novo conteúdo:');
    if (novoConteudo !== null) {
      document.getElementById('meuParagrafo').innerHTML = novoConteudo;
    }
  }

    function adicionarConteudo() {
      var textoAdicional = prompt('Digite o texto a ser adicionado:');
      if (textoAdicional !== null) {
        var paragrafo = document.getElementById('meuParagrafo');
        paragrafo.innerHTML += '<br>' + textoAdicional;
      }
    }
