<!DOCTYPE html>
<html>
<head>
  <title>Cadastro de Livro</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<li><a href="index.php">Voltar á Pagina Inicial</a></li>

<body>
<div class="h2">

  <h2>Cadastro de Livro</h2>
</div>

  <form action="processar_livro.php" method="POST">
    <label for="titulo">Título:</label>
    <input type="text" id="titulo" name="titulo" required>

    <label for="autor">Autor:</label>
    <input type="text" id="autor" name="autor" required>

    <label for="id_area">Área de Conhecimento:</label>
    <select id="id_area" name="id_area" required>
      <option value="">Selecione a área de conhecimento</option>
      <option value="1">Computação</option>
      <option value="2">Matemática</option>
      <option value="3">Engenharia</option>
    </select>
    <input type="submit" value="Cadastrar">
  </form>

</body>
</html>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $titulo = $_POST['titulo'];
  $autor = $_POST['autor'];

  include_once "conecta.php";
  
  $sql_insert_livro = "INSERT INTO livro (titulo, autor, status) VALUES ('$titulo', '$autor', 1)";

  if (mysqli_query($conn, $sql_insert_livro)) {
    echo "Livro cadastrado com sucesso!";
  } else {
    echo "Erro ao cadastrar o livro: " . mysqli_error($conn);
  }

  mysqli_close($conn);
}
?>

