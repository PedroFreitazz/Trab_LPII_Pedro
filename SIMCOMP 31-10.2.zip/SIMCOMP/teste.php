<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Estilo básico para o menu de navegação */
        ul {
            list-style: none;
            padding: 0;
            background-color: #333;
        }

        li {
            display: inline-block;
            position: relative;
        }

        li a {
            display: block;
            color: #fff;
            text-decoration: none;
            padding: 10px 20px;
        }

        li:hover ul {
            display: block;
        }

        /* Estilo para o menu drop-down */
        ul ul {
            display: none;
            position: absolute;
            background-color: #333;
        }

        ul ul li {
            display: block;
        }

        ul ul li a {
            padding: 10px 20px;
        }
    </style>
</head>
<body>
    <ul>
        <li><a href="#">Página Inicial</a></li>
        <li>
            <a href="#">Produtos</a>
            <ul>
                <li><a href="#">Produto 1</a></li>
                <li><a href="#">Produto 2</a></li>
                <li><a href="#">Produto 3</a></li>
            </ul>
        </li>
        <li>
            <a href="#">Serviços</a>
            <ul>
                <li><a href="#">Serviço 1</a></li>
                <li><a href="#">Serviço 2</a></li>
                <li><a href="regras.php">Regras</a></li>
            </ul>
        </li>
        <li><a href="#">Contato</a></li>
    </ul>
</body>
</html>
