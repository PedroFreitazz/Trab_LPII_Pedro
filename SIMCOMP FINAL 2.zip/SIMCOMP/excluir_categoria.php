<?php
include_once "conecta.php";

// Verifica se o ID da categoria foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    echo "ID da categoria não fornecido.";
    exit;
}

$categoria_id = $_GET['id'];

// Consulta para excluir a categoria
$query_excluir_categoria = "DELETE FROM Categoria WHERE Categoria_ID = $categoria_id";
$resultado_excluir_categoria = mysqli_query($conn, $query_excluir_categoria);

// Verifica se a exclusão da categoria foi bem-sucedida
if ($resultado_excluir_categoria) {
    $mensagem = "Categoria excluída com sucesso.";
} else {
    $erro_exclusao = mysqli_error($conn);

    // Verificar se o erro é devido a uma restrição de chave estrangeira
    if (strpos($erro_exclusao, 'foreign key constraint fails') !== false) {
        $mensagem = "Não é possível excluir a categoria.";
    } else {
        $mensagem = "Erro ao excluir a categoria: " . $erro_exclusao;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <a class="voltar"  href="cadcategoria.php">
        <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar" title="clique aqui para voltar">
    </a>
    <div class="container">
        <h1>Excluir Categoria</h1>

        <?php if (isset($mensagem_nao_possivel_excluir)) { ?>
            <p class="erro"><?php echo $mensagem_nao_possivel_excluir; ?></p>
        <?php } else { ?>
            <p>Tem certeza que deseja excluir esta categoria?</p>

            <form method="post">
                <button type="submit">Sim, Excluir</button>
                <br></br>
                <a href="listar_categorias.php">Voltar</a>
            </form>
        <?php } ?>
        
    </div>
</body>
</html>

