<?php
include_once "conecta.php";

$sql = "SELECT * FROM aluno";

$result = mysqli_query($conn, $sql);

if (mysqli_num_rows($result) > 0) {
  echo "<table>";
  echo "<tr><th>Nome</th><th>E-mail</th><th>Editar</th><th>Excluir</th></tr>";
  while ($row = mysqli_fetch_assoc($result)) {
    echo "<tr>";
    echo "<td>" . $row['nome'] . "</td>";
    echo "<td>" . $row['email'] . "</td>";
    echo "<td><a href='editar_aluno.php?id=" . $row['id'] . "'>Editar</a></td>";
    echo "<td><a href='excluir_aluno.php?id=" . $row['id'] . "' onclick='return confirm(\"Tem certeza que deseja excluir este aluno?\")'>Excluir</a></td>";
    echo "</tr>";
  }
  echo "</table>";
} else {
  echo "Nenhum aluno encontrado.";
}

// Fechar a conexão com o banco de dados
mysqli_close($conn);
?>
