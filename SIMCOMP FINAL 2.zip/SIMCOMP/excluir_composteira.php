<?php
include_once "conecta.php";

// Verifica se o ID da composteira foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    $mensagem = "ID da composteira não fornecido.";
} else {
    $composteira_id = $_GET['id'];

    // Consulta para excluir a composteira
    $query_excluir_composteira = "DELETE FROM Composteira WHERE Composteira_ID = $composteira_id";
    $resultado_excluir_composteira = mysqli_query($conn, $query_excluir_composteira);

    // Verifica se a exclusão da composteira foi bem-sucedida
    if ($resultado_excluir_composteira) {
        $mensagem = "Composteira excluída com sucesso.";
    } else {
        $erro_exclusao = mysqli_error($conn);

        // Verificar se o erro é devido a uma restrição de chave estrangeira
        if (strpos($erro_exclusao, 'foreign key constraint fails') !== false) {
            $mensagem = "Não é possível excluir a composteira.";
        } else {
            $mensagem = "Erro ao excluir a composteira: " . $erro_exclusao;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<a class="voltar"  href="criarcomp.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
    
    <div class="container">
        <h1>Excluir Composteira</h1>

        <p><?php echo $mensagem; ?></p>

        <a href="listar_composteira.php">Voltar</a>
    </div>
</body>
</html>
