
<?php
include_once("conecta.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $_POST['nome'];
    $impacto = $_POST['impacto'];

    $sql = "INSERT INTO Categoria (Nome, Impacto_na_composteira) VALUES ('$nome', '$impacto')";

    if ($conn->query($sql) === TRUE) {
        // Redirecione de volta à página principal com uma mensagem de sucesso
        header("Location: index.php?success=Categoria+inserida+com+sucesso");
        exit();
    } else {
        // Redirecione de volta à página principal com uma mensagem de erro
        header("Location: index.php?error=Erro+ao+inserir+a+categoria:+" . $conn->error);
        exit();
    }
}

$conn->close();
?>
