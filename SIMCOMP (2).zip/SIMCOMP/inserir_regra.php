<?php
include_once("conecta.php"); // Certifique-se de que este arquivo contém a conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtém os valores do formulário
    $temperatura = $_POST["temperatura"];
    $umidade = $_POST["umidade"];
    $valor_min = $_POST["valor_min"];
    $valor_max = $_POST["valor_max"];
    $composteira_id = $_POST["composteira_id"];

    // Prepara a consulta SQL para inserir os dados na tabela "Regra"
    $sql = "INSERT INTO Regra (Temperatura, Umidade, Valor_min, Valor_max, fk_Composteira_Composteira_ID) 
            VALUES ($temperatura, $umidade, $valor_min, $valor_max, $composteira_id)";

    // Executa a consulta e verifica se foi bem-sucedida
    if ($conn->query($sql) === TRUE) {
        echo "Regra cadastrada com sucesso.";
    } else {
        echo "Erro ao cadastrar a regra: " . $conn->error;
    }

    // Fecha a conexão com o banco de dados
    $conn->close();
}
?>
