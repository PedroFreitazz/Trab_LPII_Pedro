<!DOCTYPE html>
<html>
<head>
	<title>Escola PF</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<header>
		<nav>
			<ul>
				<li><a href="cadastro.php">Cadastro</a></li>
			</ul>
		</nav>
	</header>
	<main>
		<h1>Bem Vindo ao site da Escola PF</h1>
	</main>
	<footer>
		<p>&copy; 2023 Escola PF.</p>
	</footer>
</body>
</html>
