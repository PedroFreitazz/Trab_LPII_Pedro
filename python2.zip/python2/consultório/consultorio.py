#importar bibliotecas:
from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox

#Desenvolvimento
pacientes = []

def adiciona():
    nome = janela.lenome.text()
    pacientes.append(nome) #Adiciona no Vetor

def mostrar_dados():
    tam = len(pacientes)
    for i in range(tam):
        janela.lwlistap.addItem(pacientes[i])

#def tranferir_dados():

def limpar():
    result = QMessageBox.question(janela, "Limpar Itens", "Deseja mesmo limpar os dados?", QMessageBox.Sim, QMessageBox.Não)
    if result == QMessageBox.Sim:
        janela.lwlistap.clear()
        janela.lwatendimento.clear()

def fechar_tela():
    result = QMessageBox.question(janela,"Saindo do sistema", "Realmente deseja sair?", QMessageBox.Sim, QMessageBox.Não)
    if result == QMessageBox.Sim:
        janela.close()

#Programa Principal
app = QtWidgets.QApplication([])
janela = uic.loadUi("consultorio.ui")
janela.pbadicionar.clicked.connect(adiciona)
janela.pbtranferir.clicked.connect()
janela.pbhistorico.clicked.connect()
janela.pblimpar.clicked.connect(limpar)
janela.pbfechar.clicked.connect(fechar_tela)
janela.show()
app.exec()