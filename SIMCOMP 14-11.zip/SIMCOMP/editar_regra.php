<?php
include_once "conecta.php";

// Verifica se o ID da regra foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    echo "ID da regra não fornecido.";
    exit;
}

$regra_id = $_GET['id'];

// Verifica se o formulário de edição foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtenha os dados do formulário
    $temp_min = $_POST['Temp_min'];
    $temp_max = $_POST['Temp_max'];
    $umid_min = $_POST['Umid_min'];
    $umid_max = $_POST['Umid_max'];
    $composteira_id = $_POST['Composteira_id'];

    // Atualiza os dados no banco de dados
    $query = "UPDATE Regra SET Temp_min='$temp_min', Temp_max='$temp_max', Umid_min='$umid_min', Umid_max='$umid_max', fk_Composteira_Composteira_ID=$composteira_id WHERE Regra_ID=$regra_id";
    $resultado = mysqli_query($conn, $query);

    if ($resultado) {
        echo "Regra atualizada com sucesso.";
    } else {
        echo "Erro ao atualizar a regra: " . mysqli_error($conn);
    }
    header("Location: listar_regra.php");
    exit();
}

// Consulta para obter os dados da regra com o ID fornecido
$query_regra = "SELECT * FROM Regra WHERE Regra_ID = $regra_id";
$resultado_regra = mysqli_query($conn, $query_regra);

// Consulta para obter as composteiras disponíveis
$query_composteiras = "SELECT Composteira_ID, Nome FROM Composteira";
$resultado_composteiras = mysqli_query($conn, $query_composteiras);

// Verifica se a regra existe
if (mysqli_num_rows($resultado_regra) == 0) {
    echo "Regra não encontrada.";
    exit;
}

// Obtém os dados da regra
$row_regra = mysqli_fetch_assoc($resultado_regra);
$temp_min_regra = $row_regra['Temp_min'];
$temp_max_regra = $row_regra['Temp_max'];
$umid_min_regra = $row_regra['Umid_min'];
$umid_max_regra = $row_regra['Umid_max'];
$composteira_id_regra = $row_regra['fk_Composteira_Composteira_ID'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Regra</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
        <h1>Editar Regra</h1>

        <form method="post" action="">
            <div class="form-group">
                <h2>Temperatura</h2>
                <label for="Temp_min">Valor Mínimo:</label>
                <input type="text" id="Temp_min" name="Temp_min" value="<?php echo $temp_min_regra; ?>" required>

                <label for="Temp_max">Valor Máximo:</label>
                <input type="text" id="Temp_max" name="Temp_max" value="<?php echo $temp_max_regra; ?>" required>
            </div>

            <div class="form-group">
                <h2>Umidade</h2>
                <label for="Umid_min">Valor Mínimo:</label>
                <input type="text" id="Umid_min" name="Umid_min" value="<?php echo $umid_min_regra; ?>" required>

                <label for="Umid_max">Valor Máximo:</label>
                <input type="text" id="Umid_max" name="Umid_max" value="<?php echo $umid_max_regra; ?>" required>
            </div>

            <div class="form-group">
                <label for="Composteira_id">Selecione a Composteira:</label>
                <select id="Composteira_id" name="Composteira_id">
                    <?php
                    while ($row_composteira = mysqli_fetch_assoc($resultado_composteiras)) {
                        $selected = ($composteira_id_regra == $row_composteira['Composteira_ID']) ? 'selected' : '';
                        echo "<option value='{$row_composteira['Composteira_ID']}' $selected>{$row_composteira['Nome']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <button type="submit">Salvar</button>
            </div>
        </form>
    </div>

</body>
</html>
