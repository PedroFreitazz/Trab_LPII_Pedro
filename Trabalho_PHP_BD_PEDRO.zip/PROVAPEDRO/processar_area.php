<?php

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $nome = $_POST["nome"];

    
    include_once "conecta.php";

    
    $sql = "INSERT INTO area (nome) VALUES ('$nome')";

    if (mysqli_query($conn, $sql)) {
        echo "Área cadastrada com sucesso!";
    } else {
        echo "Erro ao cadastrar área: " . mysqli_error($conn);
    }

    
    mysqli_close($conn);
}
?>
