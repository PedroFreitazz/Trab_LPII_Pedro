package com.example.agenda;

public class Contatos {
    int id;
    String nome,tel,email;
    public Contatos (int id,String nome,String tel,String email){
        this.id = id;
        this.nome=nome;
        this.tel=tel;
        this.email=email;
    }
    public Contatos(){
        id=0;
        nome="";
        tel="";
        email="";
    }
    public Contatos(Contatos U){
        id= U.id;
        nome=U.nome;
        tel=U.tel;
        email=U.email;
    }
    public Contatos(int id){
        this.id=0;
        nome="";
        tel="";
        email="";
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getTel() {
        return tel;
    }

    public void setTel(String tel) {
        this.tel = tel;
    }

    public String getEmail(){
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    public String toString() {
        return "Contatos{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", telefone='" + tel + '\'' +
                ", Email='" + email + '\'' +
                '}';
    }
}
