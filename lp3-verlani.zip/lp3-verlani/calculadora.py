from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox
from cmath import sqrt
def calcular():
    if janela.lenum1.text()=="" and janela.lenum2.text()=="":
        QMessageBox.critical(janela,"Erro","Nenhum numero recebido")
    else: 
        n1=int(janela.lenum1.text())
        n2=int(janela.lenum2.text())
        if janela.adicao.isChecked():
            r=n1+n2
        elif janela.subtracao.isChecked():
            r=n1-n2
        elif janela.multi.isChecked():
            r=n1*n2
        elif janela.divi.isChecked():
            r=n1/n2
        elif janela.potenc.isChecked():
            r=n1**n2
        elif janela.raizq.isChecked():
            r=sqrt(n1)
        janela.leresult.setText(str(r))
def deletar():
    janela.lenum1.clear()
    janela.lenum2.clear()
    janela.leresult.clear()
def fechar_tela():
    result = QMessageBox.question(janela, "Saindo do sistema", "Deseja mesmo sair do sistema?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        janela.close()
#programa principal
app=QtWidgets.QApplication([])
janela=uic.loadUi("calculadora.ui")
janela.show()
janela.btfechar.clicked.connect(fechar_tela)
janela.btcalcular.clicked.connect(calcular)
janela.btapagar.clicked.connect(deletar)
app.exec()