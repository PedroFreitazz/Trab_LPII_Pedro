<?php
include_once "conecta.php";

// Verifica se o ID da categoria foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    echo "ID da categoria não fornecido.";
    exit;
}

$categoria_id = $_GET['id'];

// Consulta para excluir a categoria
$query_excluir_categoria = "DELETE FROM Categoria WHERE Categoria_ID = $categoria_id";
$resultado_excluir_categoria = mysqli_query($conn, $query_excluir_categoria);

// Verifica se a exclusão da categoria foi bem-sucedida
if ($resultado_excluir_categoria) {
    echo "Categoria excluída com sucesso.";
} else {
    echo "Erro ao excluir a categoria: " . mysqli_error($conn);
}
?>
