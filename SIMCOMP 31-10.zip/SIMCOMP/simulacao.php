<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Composteira</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <h1>Simulação de Composteira</h1>
        <form action="simulacao.php" method="POST">
            <div class="form-group">
                <label for="Composteira_ID">Selecione a Composteira:</label>
                <select id="Composteira_ID" name="Composteira_ID">
                    <?php
                    include_once("conecta.php");

                    // Consulta ao banco de dados para obter as composteiras disponíveis
                    $sql = "SELECT Composteira_ID, Nome FROM Composteira";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo "<option value='" . $row["Composteira_ID"] . "'>" . $row["Nome"] . "</option>";
                        }
                    } else {
                        echo "Nenhuma composteira encontrada.";
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <button type="submit">Simular</button>
            </div>
        </form>
    </div>
</body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $composteiraID = $_POST["Composteira_ID"];

    // Conexão com o banco de dados
    include_once("conecta.php");

    // Verifique se algum material é impróprio (impacto_na_composteira igual a 3 na tabela Categoria)
    $sql = "SELECT mc.Material_Composteira_ID, c.impacto_na_composteira
            FROM Material_Composteira mc
            JOIN Material m ON mc.fk_Material_Material_ID = m.Material_ID
            JOIN Categoria c ON m.fk_Categoria_Categoria_ID = c.Categoria_ID
            WHERE mc.fk_Composteira_Composteira_ID = $composteiraID";
    $result = $conn->query($sql);

    if ($result !== false) {
        $materialImproprio = false; // Flag para verificar se algum material é impróprio

        while ($row = $result->fetch_assoc()) {
            $impactoCategoria = $row["impacto_na_composteira"];

            // Verifique se o impacto_na_composteira na categoria do material é igual a 1
            if ($impactoCategoria == 1) {
                $materialImproprio = true;
                break; // Saia do loop, pois um material é impróprio
            }
        }

        if ($materialImproprio) {
            echo "<p class='error'>Pelo menos um dos materiais é impróprio para a composteira.</p>";
            exit; // Saia do script, pois pelo menos um material é impróprio
        }

        // Resto do seu código para verificar as regras da composteira
        // ...
    } else {
        echo "Erro na consulta SQL: " . $conn->error;
    }
}
?>
