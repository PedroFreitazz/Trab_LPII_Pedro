#importar bibliotecas:
from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox

def exibir_mensagem():
    dado_lido = janela.lenome.text()
    print(dado_lido)
    janela.lenome.setText("")
    if dado_lido=="":
        QMessageBox.warning(janela,"Nome:", "Nenhum nome foi digitado")
    else:
        QMessageBox.information(janela, "Nome:", "Seja bem vindo(a), " +dado_lido)
        #QMessageBox.about(janela,"information", "Seja bem vindo(a), " +dado_lido)

def fechar_tela():
    result = QMessageBox.question(janela, "Saindo do sistema", "Realmente deseja sair?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.yes:
        janela.close()

def listar_dados():
    #nome
    dado_lido = janela.lenome.text()
    if dado_lido == "":
        QMessageBox.about(janela,"Nome:","Nenhum nome foi digitado!")
    else:
        #idade
        dado_lido2 = janela.leidade.text()

    #confere idade
    if dado_lido2 == "":
        QMessageBox.about(janela,"Idade:", "Idade vazia")
    else:
        #sexo
        if janela.rbf.isChecked():
            dado_lido3 = "F"
        elif janela.rbm.isChecked():
            dado_lido3 = "M"
        else:
            dado_lido3 = "ND"

    #escolaridade
    dado_lido4 = janela.cbnivel.currentText()

    #juntar tudo
    dados = "Nome: " +dado_lido+"\nIdade: "+dado_lido2+"\nSexo: "+dado_lido3+"\nEscolaridade: "+dado_lido4

    #Limpar
    janela.lenome.setText("")
    janela.leidade.setText("")

    #Adicionar a lista
    janela.lwlista.addItem(dados)
    janela.lwlista.addItem("__________________________")

    #contador
    contar_itens()

def deletar():
    result = QMessageBox.question(janela, "Excluir Itens", "Deseja mesmo excluir tods os itens da Lista?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        janela.lwlista.clear()
        contar_itens()
    

def contar_itens():
    valor = janela.lwlista.count()
    janela.lbconta.setText("N° de Itens: "+str(valor))

def ordenar():
    janela.lwlista.sortItems()

#programa principal
app=QtWidgets.QApplication([])
janela=uic.loadUi("caixa_mensagem.ui")
janela.pbfechar.clicked.connect(fechar_tela)
janela.pbadicionar.clicked.connect(listar_dados)
janela.pbexcluir.clicked.connect(deletar)
janela.pbordenar.clicked.connect(ordenar)
janela.show()
app.exec()