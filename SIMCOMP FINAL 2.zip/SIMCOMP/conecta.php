<?php
$host = "localhost"; 
$usuario = "root"; 
$senha = ""; 
$banco = "simcomp2";

$conn = mysqli_connect($host, $usuario, $senha, $banco);

if (mysqli_connect_errno()) {
    die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}

?>
