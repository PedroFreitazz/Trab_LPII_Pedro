<?php

function addWater() {
    updateTemperature(2);
}

function advanceDays() {
    updateTemperature(-1);
    echo "Passaram-se 10 dias.";
}

function addToCompost($item) {
    echo $item . " adicionado à composteira.";
}

function updateTemperature($change) {
}

if (isset($_GET['action'])) {
    $action = $_GET['action'];
    switch ($action) {
        case 'addWater':
            addWater();
            break;
        case 'advanceDays':
            advanceDays();
            break;
        case 'addToCompost':
            $item = $_GET['item'];
            addToCompost($item);
            break;
    }
}
?>
