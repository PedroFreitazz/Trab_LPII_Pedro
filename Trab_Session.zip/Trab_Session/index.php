<!DOCTYPE html>
<html>
<head>
  <title>Página Inicial</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div class="logo">
    <img src="img/livro5.png">
  </div>
<div class="container">
    <h2>Página Inicial</h2>    
    <ul>
      <li><a href="emprestimo_livro.php">Empréstimos de Livros</a></li>
    </ul>
  </div>
</body>
</html>
