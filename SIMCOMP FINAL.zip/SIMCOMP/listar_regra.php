<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listagem de Regras</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<a class="voltar"  href="regras.php">
  <img src="img/voltar.png" alt="Texto alternativo" placeholder="voltar" title="clique aqui para voltar">
</a>
<div class="container regra">
    <h1>Listagem de Regras</h1>

    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Temperatura Mínima</th>
                <th>Temperatura Máxima</th>
                <th>Umidade Mínima</th>
                <th>Umidade Máxima</th>
                <th>Composteira</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php
            include_once("conecta.php");

            $sql = "SELECT r.Regra_ID, r.Temp_min, r.Temp_max, r.Umid_min, r.Umid_max, c.Nome as ComposteiraNome
                    FROM Regra r
                    JOIN Composteira c ON r.fk_Composteira_Composteira_ID = c.Composteira_ID";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>{$row['Regra_ID']}</td>";
                    echo "<td>{$row['Temp_min']}</td>";
                    echo "<td>{$row['Temp_max']}</td>";
                    echo "<td>{$row['Umid_min']}</td>";
                    echo "<td>{$row['Umid_max']}</td>";
                    echo "<td>{$row['ComposteiraNome']}</td>";
                    echo "<td>";
                    echo "<a href='editar_regra.php?id={$row['Regra_ID']}'>Editar</a>";
                    echo "<br>";
                    echo "<a href='excluir_regra.php?id={$row['Regra_ID']}'>Excluir</a>";
                    echo "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='7'>Nenhuma regra encontrada.</td></tr>";
            }

            $conn->close();
            ?>
        </tbody>
    </table>
</div>
</body>
</html>
