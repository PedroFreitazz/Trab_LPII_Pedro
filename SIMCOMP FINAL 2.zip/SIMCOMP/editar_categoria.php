<?php
include_once "conecta.php";

if (isset($_GET['id'])) {
    $categoria_id = $_GET['id'];

    // Consulta para obter os detalhes da categoria específica
    $query = "SELECT * FROM Categoria WHERE Categoria_ID = $categoria_id";
    $resultado = mysqli_query($conn, $query);

    if (!$resultado) {
        die("Erro na consulta: " . mysqli_error($conn));
    }

    $categoria = mysqli_fetch_assoc($resultado);

    // Processar o formulário de edição
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $nome = $_POST['nome'];
        $impacto = $_POST['impacto'];

        // Atualizar os detalhes da categoria no banco de dados
        $atualizar_query = "UPDATE Categoria SET Nome = '$nome', Impacto_na_composteira = $impacto WHERE Categoria_ID = $categoria_id";
        $atualizar_resultado = mysqli_query($conn, $atualizar_query);

        if (!$atualizar_resultado) {
            die("Erro na atualização: " . mysqli_error($conn));
        }

        // Redirecionar de volta para a lista de categorias após a edição
        header("Location: listar_categorias.php");
        exit();
    }
} else {
    die("ID da categoria não fornecido.");
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Categoria</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<a class="voltar"  href="index.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>

    <div class="container">
        <h1>Editar Categoria</h1>

        <form method="post">
        <div class="form-group">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" value="<?php echo $categoria['Nome']; ?>" required>
        </div> 
    
        <div class="form-group">

            <label for="impacto">Impacto na Composteira:</label>
            <select id="impacto" name="impacto" required>
                <option value="1" <?php echo ($categoria['Impacto_na_composteira'] == 1) ? 'selected' : ''; ?>>Improprio</option>
                <option value="2" <?php echo ($categoria['Impacto_na_composteira'] == 2) ? 'selected' : ''; ?>>Proprio</option>
            </select>
        </div> 
        <div class="form-group">
            <button type="submit">Salvar</button>
        </div> 
    
          
    
        </form>
    </div>

</body>
</html>
