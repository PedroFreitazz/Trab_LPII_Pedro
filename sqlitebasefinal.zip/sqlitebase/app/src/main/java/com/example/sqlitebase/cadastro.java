package com.example.sqlitebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class cadastro extends AppCompatActivity {
    EditText logincad,senhain,senharep;
    Button cadast;
    dbhelper sql;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
        logincad=findViewById(R.id.logincad);
        senhain=findViewById(R.id.senhain);
        senharep=findViewById(R.id.senharep);
        cadast=findViewById(R.id.cadast);
        sql= new dbhelper(this);
        cadast.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String loginnovo = logincad.getText().toString().trim();
                String senhainsere = senhain.getText().toString().trim();
                String senharepete= senharep.getText().toString().trim();
                if (loginnovo.isEmpty()){
                    Toast.makeText(cadastro.this,"Insira um usuario",Toast.LENGTH_SHORT).show();
                }
                if (senhainsere.isEmpty()){
                    Toast.makeText(cadastro.this,"Insira sua senha",
                            Toast.LENGTH_SHORT).show();
                }
                if(senharepete.isEmpty()){
                    Toast.makeText(cadastro.this,"reinsira sua senha",Toast.LENGTH_SHORT).show();
                }
                else if (senhainsere.isEmpty()||senharepete.isEmpty()){
                    Toast.makeText(cadastro.this,"refaça sua senha",Toast.LENGTH_SHORT).show();
                }
                else if (!senhainsere.equals(senharepete)) {
                    Toast.makeText(cadastro.this, "Senhas não são iguais", Toast.LENGTH_SHORT).show();

                }
                else{
                    long resultado= sql.Insert(loginnovo,senhainsere);
                    if(resultado > 0){
                        Toast.makeText(cadastro.this, "Cadastro sucesso", Toast.LENGTH_SHORT).show();
                        Intent i =getIntent();
                        i.putExtra("username",loginnovo);
                        setResult(1,i);
                        finish();

                    }
                }
            }
        });
    }
}