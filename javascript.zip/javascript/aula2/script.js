function ligar_lampada(){
    var img = document.getElementById('myImage').src='lampadaon.gif';
    img.src = 'lampadaon.gif';
}

function desligar_lampada(){
    var img = document.getElementById('myImage').src='lampadaoff.gif';
    img.src = 'lampadaoff.gif';
}
function fonte(){
    var titulo = document.getElementById("sec1").innerHTML = "Mudei o titulo!";
}
function voltar(){
    var titulo = document.getElementById("sec1");
    titulo.innerHTML = "Mudei o titulo de novo!";
}
function sumir(){
    var parag2 = document.getElementById("sec3");
    parag2.style.display = "none";
}
function aparecer(){
    var parag2 = document.getElementById("sec3");
    parag2.style.display = "block";
}