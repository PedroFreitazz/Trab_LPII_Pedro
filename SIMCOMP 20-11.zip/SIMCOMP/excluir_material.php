<?php
include_once "conecta.php";

if (isset($_GET['id'])) {
    $material_id = $_GET['id'];

    // Verificar se o formulário foi enviado para confirmar a exclusão
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Excluir o material do banco de dados
        $excluir_query = "DELETE FROM Material WHERE Material_ID = $material_id";
        $excluir_resultado = mysqli_query($conn, $excluir_query);

        if (!$excluir_resultado) {
            die("Erro na exclusão: " . mysqli_error($conn));
        }

        // Redirecionar de volta para a lista de materiais após a exclusão
        header("Location: lista_materiais.php");
        exit();
    }
} else {
    die("ID do material não fornecido.");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <!-- Mesmo cabeçalho do arquivo anterior -->
</head>
<body>
    <div class="container">
        <h1>Excluir Material</h1>

        <p>Tem certeza que deseja excluir este material?</p>

        <form method="post">
            <button type="submit">Sim, Excluir</button>
            <a href="lista_materiais.php">Cancelar</a>
        </form>
    </div>
</body>
</html>
