package com.example.sqlbase;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class DBHelper extends SQLiteOpenHelper {

    private static int versao = 1;

    private static String NomeDB = "base.db";


    String[] sql = {

            "CREATE TABLE USUARIO (ID INTEGER, Username TEXT, PASSWORD TEXT," +
                    "PRIMARY KEY(ID AUTOINCREMENT));"


    };


    public DBHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory) {
        super(context, NomeDB, null, versao);
    }

    @Override


    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        for (int i = 0; i < sql.length; i++) {
            sqLiteDatabase.execSQL(sql(i));

        }
    }

    private String sql(int i) {
        return null;
    }


    @Override


    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        versao++;
        SQLiteDatabase.execSQL("DROP TABLE IF EXISTS USUARIOS");
        onCreate(sqLiteDatabase);


    }

    public long Insert(String username, String password) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        ContentValues valor = new ContentValues();
        valor.put("USERNAME", username);
        valor.put("PASSWORD", password);


        return SQLiteDatabase.insert("USUARIOS", null, valor);
    }

    ;


    public long Update(int id, String username, String password) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        ContentValues valor= new ContentValues();
        valor.put("PASSWORD", password);


        return sqLiteDatabase.update("USUARIOS", valor, "id=?", new String[]{String.valueOf(id)});
    }

    public long Delete(int id) {
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
        return sqLiteDatabase.delete("USUARIOS", "id=?", new String[]{String.valueOf(id)});
    }

    @SuppressLint("Range")
    public long Select(String username, String password){
        SQLiteDatabase sqLiteDatabase = getReadableDatabase();
          Cursor c = sqLiteDatabase.rawQuery("SELECT * FROW USUARIOS" + "WHERE username=? AND Passoword=?", new String[]{username, password});
          c.moveToFirst();
          if (c.getCount()==1){
                return c.getInt(c.getColumnIndex("id"));
          };
        return -1;
    }

}













