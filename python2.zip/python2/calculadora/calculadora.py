#importar bibliotecas:
from cmath import sqrt
from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox



def calcular():

    #conferindo os dados dos campos do 1° número
    if janela.len1.text() == "" and janela.len2.text() == "":
        QMessageBox.information(janela, "Information", "Por favor, digite um número na primeira caixa!")
        
    else:
        n1 = int(janela.len1.text())
        n2 = int(janela.len2.text())
    
        #conferindo a operação
        if janela.rbmais.isChecked():
            res = n1 + n2
        elif janela.rbmenos.isChecked():
            res = n1 - n2
        elif janela.rbmult.isChecked():
            res = n1 * n2
        elif janela.rbdiv.isChecked():
            res = n1 / n2
        elif janela.rbpoten.isChecked():
            res = n1**n2
        elif janela.rbraiz.isChecked():
            res1 = n1+n2
            res = sqrt(res1)
        else:
            QMessageBox.information(janela, "Information", "Selecione uma operação para dar continuidade na conta")

    

    janela.lenresultado.setText(str(res))




def limpar():
    result = QMessageBox.question(janela, "Limpar Itens", "Deseja mesmo limpar os dados?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.Yes:
        janela.len1.clear()
        janela.len2.clear()
        janela.lenresultado.clear()

def sair():
    result = QMessageBox.question(janela, "Saindo do sistema", "Realmente deseja sair?", QMessageBox.Yes, QMessageBox.No)
    if result == QMessageBox.yes:
        janela.close()     



#programa principal
app=QtWidgets.QApplication([])
janela=uic.loadUi("calculadora.ui")
janela.pbcalcular.clicked.connect(calcular)
janela.pblimpar.clicked.connect(limpar)
janela.pbsair.clicked.connect(sair)
janela.show()
app.exec()