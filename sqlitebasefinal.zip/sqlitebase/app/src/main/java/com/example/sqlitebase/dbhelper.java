package com.example.sqlitebase;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class dbhelper extends SQLiteOpenHelper {

    private static int versao = 1;
    private static String nomedb="base2.db";
    String[] sql = {"create table usuarios( id integer, username text, password text, primary key (id autoincrement));"};
    public dbhelper(@Nullable Context context) {

        super(context, nomedb, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        for (int i=0; i<sql.length; i++){
            db.execSQL(sql[i]);
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        versao++;
        db.execSQL("DROP TABLE IF EXISTS USUARIOS");
        onCreate(db);
    }
    public long Insert (String username, String password){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valor = new ContentValues();
        valor.put("username",username);
        valor.put("password",password);
        return db.insert("USUARIOS",null,valor);
    }
    public long Update(int id, String username, String password){
        SQLiteDatabase db= getWritableDatabase();
        ContentValues valor = new ContentValues();
        valor.put("username",username);
        valor.put("password",password);
        return db.update("USUARIOS", valor, "id=?",new String[]{String.valueOf(id)});
    }
    public long Delete (int id){
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("USUARIOS", "id=?", new String[]{String.valueOf(id)});
    }
    @SuppressLint("Range")
    public long Select(String username, String password){
        SQLiteDatabase db = getReadableDatabase();
        Cursor c= db.rawQuery("SELECT * FROM USUARIOS WHERE username=? AND password=?", new String[]{username,password});
        c.moveToFirst();
        if (c.getCount()==1){
            return c.getInt(c.getColumnIndex("id"));
        }
        return-1;
    };
    @SuppressLint("Range")
    public List<usuarios> SelectAll(){
      SQLiteDatabase db = getReadableDatabase();
      Cursor c= db.rawQuery("SELECT * FROM USUARIOS", null);
      List<usuarios> listausuarios = new ArrayList<>();
      c.moveToFirst();
      if(c.getCount()>0){
          do {
            int id= c.getInt(c.getColumnIndex("id"));
            String username = c.getString(c.getColumnIndex("username"));
            String password = c.getString(c.getColumnIndex("password"));
            listausuarios.add(new usuarios(id,username,password));
          }while(c.moveToNext());
          } return listausuarios;
      }
      public usuarios SelectID(int id){
        SQLiteDatabase db= getReadableDatabase();
        Cursor c= db.rawQuery("SELECT * FROM USUARIOS WHERE id=?", new String[]{String.valueOf(id)});
        c.moveToFirst();
        if(c.getCount()==1){
            @SuppressLint("Range") String username = c.getString(c.getColumnIndex("username"));
            @SuppressLint("Range") String password = c.getString(c.getColumnIndex("password"));
            return new usuarios(id,username,password);
        }
        return null;
    }
}
