package com.example.agenda;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ListView;

public class consultar extends AppCompatActivity {

    ListView listacontato;
    Button con_atualizar, con_deletar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultar);
        listacontato = findViewById(R.id.listacontato);
        con_atualizar =  findViewById(R.id.con_atualizar);
        con_deletar = findViewById(R.id.con_deletar);
    }
}