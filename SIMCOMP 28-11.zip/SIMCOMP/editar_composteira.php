<?php
include_once "conecta.php";

// Verifica se o ID da composteira foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    echo "ID da composteira não fornecido.";
    exit;
}

$composteira_id = $_GET['id'];

// Verifica se o formulário de edição foi enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtenha os dados do formulário
    $nome = mysqli_real_escape_string($conn, $_POST['nome']);
    $umidade = mysqli_real_escape_string($conn, $_POST['umidade']);
    $temperatura = mysqli_real_escape_string($conn, $_POST['temperatura']);
    $materiais = $_POST['materiais'];
    $tempo_compostagem = mysqli_real_escape_string($conn, $_POST['tempo_compostagem']);

    // Atualiza os dados no banco de dados
    $query = "UPDATE Composteira SET Nome='$nome', Umidade='$umidade', Temperatura='$temperatura', Tempo_Compostagem='$tempo_compostagem' WHERE Composteira_ID=$composteira_id";
    $resultado = mysqli_query($conn, $query);

    if ($resultado) {
        // Remove os materiais antigos associados à composteira
        $query_remove_materiais = "DELETE FROM Material_Composteira WHERE fk_Composteira_Composteira_ID = $composteira_id";
        $resultado_remove_materiais = mysqli_query($conn, $query_remove_materiais);

        // Insere os novos materiais associados à composteira
        foreach ($materiais as $material_id) {
            $query_insere_materiais = "INSERT INTO Material_Composteira (fk_Composteira_Composteira_ID, fk_Material_Material_ID) VALUES ($composteira_id, $material_id)";
            mysqli_query($conn, $query_insere_materiais);
        }

        echo "Composteira atualizada com sucesso.";
    } else {
        echo "Erro ao atualizar a composteira: " . mysqli_error($conn);
    }
}

// Consulta para obter os dados da composteira com o ID fornecido
$query_composteira = "SELECT * FROM Composteira WHERE Composteira_ID = $composteira_id";
$resultado_composteira = mysqli_query($conn, $query_composteira);

// Consulta para obter os materiais associados à composteira
$query_materiais_associados = "SELECT fk_Material_Material_ID FROM Material_Composteira WHERE fk_Composteira_Composteira_ID = $composteira_id";
$resultado_materiais_associados = mysqli_query($conn, $query_materiais_associados);

// Lista de materiais associados à composteira
$materiais_associados = [];
while ($row = mysqli_fetch_assoc($resultado_materiais_associados)) {
    $materiais_associados[] = $row['fk_Material_Material_ID'];
}

// Verifica se a composteira existe
if (mysqli_num_rows($resultado_composteira) == 0) {
    echo "Composteira não encontrada.";
    exit;
}

// Obtém os dados da composteira
$row = mysqli_fetch_assoc($resultado_composteira);
$nome_composteira = $row['Nome'];
$umidade_composteira = $row['Umidade'];
$temperatura_composteira = $row['Temperatura'];
$tempo_compostagem_composteira = $row['Tempo_Compostagem'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Composteira</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

    <div class="container">
        <h1>Editar Composteira</h1>

        <form method="post" action="">
            <div class="form-group">
                <label for="nome">Nome da Composteira:</label>
                <input type="text" id="nome" name="nome" value="<?php echo $nome_composteira; ?>" placeholder="Digite o nome da composteira" required>
            </div>

            <div class="form-group">
                <label for="umidade">Umidade:</label>
                <input type="text" id="umidade" name="umidade" value="<?php echo $umidade_composteira; ?>" placeholder="Digite a umidade da composteira" required>
            </div>

            <div class="form-group">
                <label for="temperatura">Temperatura:</label>
                <input type="text" id="temperatura" name="temperatura" value="<?php echo $temperatura_composteira; ?>" placeholder="Digite a temperatura da composteira" required>
            </div>

            <div class="form-group">
                <label for="materiais">Selecione os Materiais:</label>
                <select id="materiais" name="materiais[]" multiple class="custom-select">
                    <?php
                    $query_materiais = "SELECT Material_ID, Nome FROM Material";
                    $resultado_materiais = $conn->query($query_materiais);

                    if ($resultado_materiais->num_rows > 0) {
                        while ($row_material = $resultado_materiais->fetch_assoc()) {
                            $material_id = $row_material['Material_ID'];
                            $selected = in_array($material_id, $materiais_associados) ? 'selected' : '';
                            echo "<option value='$material_id' $selected>" . $row_material['Nome'] . "</option>";
                        }
                    } else {
                        echo "Nenhum material encontrado.";
                    }
                    ?>
                </select>
            </div>

            <div class="form-group">
                <label for="tempo_compostagem">Tempo De Compostagem (em dias):</label>
                <select id="tempo_compostagem" name="tempo_compostagem">
                    <option value="1" <?php echo ($tempo_compostagem_composteira == 1) ? 'selected' : ''; ?>>10 dias</option>
                    <option value="2" <?php echo ($tempo_compostagem_composteira == 2) ? 'selected' : ''; ?>>20 dias</option>
                    <option value="3" <?php echo ($tempo_compostagem_composteira == 3) ? 'selected' : ''; ?>>30 dias</option>
                </select>
            </div>

            <div class="form-group">
                <button type="submit">Salvar</button>
            </div>
        </form>
    </div>

</body>
</html>
