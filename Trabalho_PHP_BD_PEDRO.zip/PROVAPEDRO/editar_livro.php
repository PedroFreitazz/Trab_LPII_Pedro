<?php
if (isset($_GET['id'])) {
  $livro_id = $_GET['id'];

  include_once "conecta.php";

  $sql_areas = "SELECT id, nome FROM area";
  $result_areas = mysqli_query($conn, $sql_areas);
  $areas = mysqli_fetch_all($result_areas, MYSQLI_ASSOC);

  if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo = $_POST['titulo'];
    $autor = $_POST['autor'];
    $id_area = $_POST['id_area'];

    $sql = "UPDATE livro SET titulo = '$titulo', autor = '$autor', id_area = '$id_area' WHERE id = '$livro_id'";

    if (mysqli_query($conn, $sql)) {
      echo "Livro atualizado com sucesso!";
    } else {
      echo "Erro ao atualizar o livro: " . mysqli_error($conn);
    }

    mysqli_close($conn);
  } else {
    $sql = "SELECT id, titulo, autor, id_area FROM livro WHERE id = '$livro_id'";
    $result = mysqli_query($conn, $sql);
    $livro = mysqli_fetch_assoc($result);

    mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Editar Livro</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
  <h1>Editar Livro</h1>
  <form method="POST" action="editar_livro.php?id=<?php echo $livro['id']; ?>">
    <label for="titulo">Título:</label>
    <input type="text" id="titulo" name="titulo" value="<?php echo $livro['titulo']; ?>" required><br><br>

    <label for="autor">Autor:</label>
    <input type="text" id="autor" name="autor" value="<?php echo $livro['autor']; ?>" required><br><br>

    <label for="id_area">Área de Conhecimento:</label>
    <select id="id_area" name="id_area" required>
      <?php foreach ($areas as $area): ?>
        <option value="<?php echo $area['id']; ?>" <?php if ($area['id'] == $livro['id_area']) echo 'selected'; ?>><?php echo $area['nome']; ?></option>
      <?php endforeach; ?>
    </select><br><br>

    <input type="submit" value="Atualizar">
  </form>
</body>
</html>

<?php
  }
} else {
  echo "ID do livro não especificado.";
  exit;
}
?>
