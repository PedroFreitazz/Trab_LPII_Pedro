<?php
$serv = "localhost";
$user ="root";
$pass ="";
$db ="escola";

$conexao = mysqli_connect($serv, $user, $pass, $db);
echo "Cadastro realizado com sucesso!";

if (!$conexao) {
	die("Erro na conexão: ");
}

?>
