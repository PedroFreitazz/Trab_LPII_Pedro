# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'clientes.ui'
##
## Created by: Qt User Interface Compiler version 5.15.2
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(798, 670)
        MainWindow.setStyleSheet(u"background-color: rgb(60, 187, 255);")
        self.centralwidget = QWidget(MainWindow)
        self.centralwidget.setObjectName(u"centralwidget")
        self.groupBox_2 = QGroupBox(self.centralwidget)
        self.groupBox_2.setObjectName(u"groupBox_2")
        self.groupBox_2.setGeometry(QRect(50, 20, 711, 441))
        font = QFont()
        font.setPointSize(14)
        font.setBold(False)
        font.setWeight(50)
        self.groupBox_2.setFont(font)
        self.groupBox_2.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(self.groupBox_2)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(60, 50, 81, 31))
        font1 = QFont()
        font1.setPointSize(15)
        self.label_3.setFont(font1)
        self.label_4 = QLabel(self.groupBox_2)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(20, 90, 121, 41))
        self.label_4.setFont(font1)
        self.lnome = QLineEdit(self.groupBox_2)
        self.lnome.setObjectName(u"lnome")
        self.lnome.setGeometry(QRect(150, 50, 541, 31))
        self.lnome.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.lnome.setInputMethodHints(Qt.ImhHiddenText)
        self.lender = QLineEdit(self.groupBox_2)
        self.lender.setObjectName(u"lender")
        self.lender.setGeometry(QRect(150, 100, 541, 31))
        self.lender.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.lemail = QLineEdit(self.groupBox_2)
        self.lemail.setObjectName(u"lemail")
        self.lemail.setGeometry(QRect(150, 150, 541, 31))
        self.lemail.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.label_5 = QLabel(self.groupBox_2)
        self.label_5.setObjectName(u"label_5")
        self.label_5.setGeometry(QRect(30, 190, 121, 41))
        self.label_5.setFont(font1)
        self.label_6 = QLabel(self.groupBox_2)
        self.label_6.setObjectName(u"label_6")
        self.label_6.setGeometry(QRect(50, 140, 81, 41))
        self.label_6.setFont(font1)
        self.label_7 = QLabel(self.groupBox_2)
        self.label_7.setObjectName(u"label_7")
        self.label_7.setGeometry(QRect(80, 280, 61, 41))
        self.label_7.setFont(font1)
        self.label_8 = QLabel(self.groupBox_2)
        self.label_8.setObjectName(u"label_8")
        self.label_8.setGeometry(QRect(50, 330, 91, 41))
        self.label_8.setFont(font1)
        self.label_9 = QLabel(self.groupBox_2)
        self.label_9.setObjectName(u"label_9")
        self.label_9.setGeometry(QRect(80, 240, 61, 41))
        self.label_9.setFont(font1)
        self.lcpf = QLineEdit(self.groupBox_2)
        self.lcpf.setObjectName(u"lcpf")
        self.lcpf.setGeometry(QRect(150, 247, 221, 31))
        self.lcpf.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.lcep = QLineEdit(self.groupBox_2)
        self.lcep.setObjectName(u"lcep")
        self.lcep.setGeometry(QRect(150, 290, 181, 31))
        self.lcep.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.cbest = QComboBox(self.groupBox_2)
        self.cbest.setObjectName(u"cbest")
        self.cbest.setGeometry(QRect(150, 330, 91, 31))
        self.cbest.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.cbcid = QComboBox(self.groupBox_2)
        self.cbcid.setObjectName(u"cbcid")
        self.cbcid.setGeometry(QRect(150, 380, 471, 31))
        self.cbcid.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.label_10 = QLabel(self.groupBox_2)
        self.label_10.setObjectName(u"label_10")
        self.label_10.setGeometry(QRect(50, 380, 91, 41))
        self.label_10.setFont(font1)
        self.ltel = QLineEdit(self.groupBox_2)
        self.ltel.setObjectName(u"ltel")
        self.ltel.setGeometry(QRect(150, 200, 171, 31))
        self.ltel.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"border-style:outset;\n"
"border-width:2px;")
        self.pbfiltrar = QPushButton(self.groupBox_2)
        self.pbfiltrar.setObjectName(u"pbfiltrar")
        self.pbfiltrar.setGeometry(QRect(250, 330, 81, 31))
        font2 = QFont()
        font2.setPointSize(10)
        self.pbfiltrar.setFont(font2)
        self.pbfiltrar.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"")
        self.verificacpf = QPushButton(self.groupBox_2)
        self.verificacpf.setObjectName(u"verificacpf")
        self.verificacpf.setGeometry(QRect(380, 250, 93, 28))
        self.verificacpf.setStyleSheet(u"background-color: rgb(255, 255, 255);")
        self.groupBox_3 = QGroupBox(self.centralwidget)
        self.groupBox_3.setObjectName(u"groupBox_3")
        self.groupBox_3.setGeometry(QRect(50, 480, 721, 141))
        font3 = QFont()
        font3.setPointSize(12)
        font3.setBold(False)
        font3.setWeight(50)
        self.groupBox_3.setFont(font3)
        self.groupBox_3.setAlignment(Qt.AlignCenter)
        self.btcadastrar = QPushButton(self.groupBox_3)
        self.btcadastrar.setObjectName(u"btcadastrar")
        self.btcadastrar.setGeometry(QRect(30, 60, 181, 61))
        font4 = QFont()
        font4.setPointSize(12)
        font4.setBold(True)
        font4.setWeight(75)
        self.btcadastrar.setFont(font4)
        self.btcadastrar.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        icon = QIcon()
        icon.addFile(u"../icones/cadastro.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btcadastrar.setIcon(icon)
        self.btcadastrar.setIconSize(QSize(40, 40))
        self.pushButton_2 = QPushButton(self.groupBox_3)
        self.pushButton_2.setObjectName(u"pushButton_2")
        self.pushButton_2.setGeometry(QRect(270, 60, 181, 61))
        self.pushButton_2.setFont(font4)
        self.pushButton_2.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"\n"
"")
        icon1 = QIcon()
        icon1.addFile(u"../icones/2392275.png", QSize(), QIcon.Normal, QIcon.Off)
        self.pushButton_2.setIcon(icon1)
        self.pushButton_2.setIconSize(QSize(40, 40))
        self.btfechar = QPushButton(self.groupBox_3)
        self.btfechar.setObjectName(u"btfechar")
        self.btfechar.setGeometry(QRect(510, 60, 181, 61))
        self.btfechar.setFont(font4)
        self.btfechar.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"")
        icon2 = QIcon()
        icon2.addFile(u"../icones/download.png", QSize(), QIcon.Normal, QIcon.Off)
        self.btfechar.setIcon(icon2)
        self.btfechar.setIconSize(QSize(55, 55))
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QMenuBar(MainWindow)
        self.menubar.setObjectName(u"menubar")
        self.menubar.setGeometry(QRect(0, 0, 798, 26))
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QStatusBar(MainWindow)
        self.statusbar.setObjectName(u"statusbar")
        MainWindow.setStatusBar(self.statusbar)

        self.retranslateUi(MainWindow)

        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"MainWindow", None))
        self.groupBox_2.setTitle(QCoreApplication.translate("MainWindow", u"Cadastro de Clientes", None))
        self.label_3.setText(QCoreApplication.translate("MainWindow", u"Nome:", None))
        self.label_4.setText(QCoreApplication.translate("MainWindow", u"Endere\u00e7o: ", None))
        self.label_5.setText(QCoreApplication.translate("MainWindow", u"Telefone:", None))
        self.label_6.setText(QCoreApplication.translate("MainWindow", u"E-mail:", None))
        self.label_7.setText(QCoreApplication.translate("MainWindow", u"CEP:", None))
        self.label_8.setText(QCoreApplication.translate("MainWindow", u"Estado:", None))
        self.label_9.setText(QCoreApplication.translate("MainWindow", u"CPF:", None))
        self.label_10.setText(QCoreApplication.translate("MainWindow", u"Cidade:", None))
        self.pbfiltrar.setText(QCoreApplication.translate("MainWindow", u"Filtrar", None))
        self.verificacpf.setText(QCoreApplication.translate("MainWindow", u"Verifica", None))
        self.groupBox_3.setTitle(QCoreApplication.translate("MainWindow", u"Escolha uma op\u00e7\u00e3o", None))
        self.btcadastrar.setText(QCoreApplication.translate("MainWindow", u"Cadastrar", None))
        self.pushButton_2.setText(QCoreApplication.translate("MainWindow", u"Listar dados", None))
        self.btfechar.setText(QCoreApplication.translate("MainWindow", u"Fechar", None))
    # retranslateUi

