<!DOCTYPE html>
<html>
<head>
    <title>Produtos - Loja de Artigos Musicais</title>
    <link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
    <header>
            <h1>PFmusic</h1>
        </div>
    </header>

    <nav>
        <ul>
            <li><a href="index.php">Início</a></li>
            <li><a href="produtos.php">Produtos</a></li>
            <li><a href="contato.php">Contato</a></li>
            <li><a href="carrinho.php">Carrinho</a></li> <!-- Adicione esta linha -->

        </ul>
    </nav>

    <section class="main-content">
        <h2>Nossos Produtos</h2>
        <ul class="product-list">
            <li>
                <img src="img/explorer.png" alt="Guitarra">
                <h3>Guitarra Elétrica</h3>
                <p>Modelo Explorer, disponível em diversas cores.</p>
                <p class="price">$499.99</p>
                <a href="#">Adicionar ao Carrinho</a>
            </li>
            <li>
                <img src="img/Lespaul.png" alt="GuitarraL">
                <h3>Guitarra Les Paul</h3>
                <p>Buckethead Signature Les Paul Electric Guitar.</p>
                <p class="price">$299.99</p>
                <a href="#">Adicionar ao Carrinho</a>
            </li>
            <!-- Adicione mais itens aqui -->
        </ul>
    </section>

    <footer>
        <p>&copy; 2023 Loja de Artigos Musicais</p>
    </footer>
</body>
</html>
