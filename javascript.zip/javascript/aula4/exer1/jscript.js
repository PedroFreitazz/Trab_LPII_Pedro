function estilizarPagina(){
    var elemento1 = document.getElementById("divUm");
    elemento1.style.background = "#DB7093";
    elemento1.style.height = "110px";
    elemento1.style.width = "295px";
    elemento1.style.borderRadius = "10px";
    elemento1.style.padding = "14px";
    elemento1.style.color = "white";
    elemento1.style.textDecoration = "underline";
    elemento1.style.fontFamily = "system-ui";
    elemento1.style.fontSize = "40px";
    elemento1.style.textAlign = "center";
   
} 