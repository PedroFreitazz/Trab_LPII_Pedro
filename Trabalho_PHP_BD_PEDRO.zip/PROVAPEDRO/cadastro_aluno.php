
<!DOCTYPE html>
<html>
<head>
  <title>Cadastro de Aluno</title>
  <link rel="stylesheet" type="text/css" href="style.css">

</head>
<li><a href="index.php">Voltar á Pagina Inicial</a></li>


<body>
<div class="h2">

  <h2>Cadastro de Aluno</h2>
</div>
  <form action="processar_aluno.php" method="POST">
    <label for="matricula">Matrícula:</label>
    <input type="text" id="matricula" name="matricula" required>

    <label for="nome">Nome:</label>
    <input type="text" id="nome" name="nome" required>

    <label for="email">Email:</label>
    <input type="email" id="email" name="email" required>

    <label for="cpf">CPF:</label>
    <input type="text" id="cpf" name="cpf" required>

    <label for="data_nasc">Data de Nascimento:</label>
    <input type="date" id="data_nasc" name="data_nasc" required>
    <br>
    <br>

    <input type="submit" value="Cadastrar Aluno">
  </form>

  


