from PyQt5 import uic,QtWidgets
from PyQt5.QtWidgets import QMessageBox
dicionario={}
def adicionar():
    nome=janela.nome.text()
    idade=janela.idade.text()
    if (nome=="" or idade==""):
        QMessageBox.about(janela,"Alerta","Não foi inserido nome ou idade")
    else:
        dicionario.update({nome: idade})
        janela.filtro.addItem(idade)
        janela.nome.clear()
        janela.idade.clear()
        janela.nome.setFocus()
def fechar():
    result=QMessageBox.question(janela, "Alerta", "Deseja sair do sitema?")
    if result== QMessageBox.Yes:
        janela.close()

def listar():
    janela.lista.clear()
    filtro_idade=janela.filtro.currentText()
    for chave in dicionario.keys():
        if(filtro_idade != 'Geral'):
            if(filtro_idade == dicionario[chave]):
                janela.lista.addItem(chave+"-"+dicionario[chave])
        else:
            janela.lista.addItem(chave+"-"+dicionario[chave])
def limpar():
    janela.lista.clear()
    janela.nome.clear()
    janela.idade.clear()
    janela.nome.setFocus()

app=QtWidgets.QApplication([])
janela=uic.loadUi("dicionario.ui")
janela.PBfechar.clicked.connect(fechar)
janela.PBad.clicked.connect(adicionar)
janela.limpar.clicked.connect(limpar)
janela.listar.clicked.connect(listar)
janela.show()
app.exec()

