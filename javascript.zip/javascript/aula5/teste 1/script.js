window.onload = function(){
    var elemento = document.getElementById("bloco");
    elemento.addEventListener("mouseover", moveSobre);
    elemento.addEventListener("mouseout", moveParaFora);
    }
    function moveSobre(){
    this.innerHTML = "Obrigado!";
    }
    function moveParaFora(){
    this.innerHTML = "Passe o mouse";
    }

    /*
window.onload = function(){
    var elemento = document.getElementById("bloco");
    elemento.addEventListener("mouseover", moveSobre);
    elemento.addEventListener("mouseout", moveParaFora);
    
    }
    function moveSobre(){
        var textelemento = document.getElementById("text");
        textelemento.innerHTML = "Há VAGAS";
    }
    function moveParaFora(){
        var textelemento = document.getElementById("text");
        textelemento.innerHTML = "Sem VAGAS";
    }
    */