# Importar bibliotecas:
from cmath import sqrt
from PyQt5 import uic, QtWidgets
from PyQt5.QtWidgets import QMessageBox

# Definir a função para listar os dados
def calcula():
    N1 = int(janela.Lb1n1.text())
    N2 = int(janela.Lb1n2.text()) 
    if janela.Lb1N1.text=="" and janela.Lb1N2.text== "":
        QMessageBox.critical(janela,"erro","Números em branco")         
    else:
        if janela.Rb1.isChecked():
            R=N1+N2
        elif janela.Rb2.isChecked():
            R=N1-N2 
        elif janela.Rb3.isChecked():
            R=N1*N2
        elif janela.Rb4.isChecked():
            R=N1/N2
        elif janela.Rb5.isChecked():
            R=N1**N2
        elif janela.Rb6.isChecked():
            R=sqrt(N1)
    janela.Lb1Resultado.setText(str(R))
def Limpa():
    janela.Lb1N1.setText("")
    janela.Lb1N1.setText("")
    janela.Lb1N1.setText("")   

def Sai():
    result = QMessageBox.question(janela,"Saindo do Sistema""Deseja mesmo sair do Sistema?";)
    if result == QMessageBox.yes:
        janela.close()
      
    
# Programa principal
app = QtWidgets.QApplication([])
janela = uic.loadUi("calculadora.ui")
janela.btncalcula.clicked.connect(Calcula)
janela.btnlimpa.clicked.connect(Limpa)
janela.btnsai.clicked.connect(Sai)
janela.show()

# Rodar o loop principal do aplicativo
app.exec()
