<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Autenticação</title>
  </head>
  <body>
    <?php
      $nome = $_POST['nome'];
      $senha = $_POST['senha'];
      
      if ($nome === 'ana' && $senha === '12345') {
        echo '<p>Autenticação realizada com sucesso</p>';
      } else {
        echo '<p>Você não tem permissão de visualizar essa página</p>';
      }
    ?>
  </body>
</html>
