<?php
include_once "conecta.php";

// Verifica se a conexão foi estabelecida com sucesso
if (!$conn) {
    die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}

$query = "SELECT * FROM Categoria";
$resultado = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Categorias</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body class="body-categorias">

    <div class="container">
        <h1>Lista de Categorias</h1>

        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Impacto na Composteira</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php
                while ($row = mysqli_fetch_assoc($resultado)) {
                    echo "<tr>";
                    echo "<td>{$row['Nome']}</td>";
                    echo "<td>{$row['Impacto_na_composteira']}</td>";
                    echo "<td class='actions'>";
                    echo "<a href='editar_categoria.php?id={$row['Categoria_ID']}'>Editar</a>";
                    echo "<a href='excluir_categoria.php?id={$row['Categoria_ID']}' onclick='return confirm(\"Tem certeza que deseja excluir?\")'>Excluir</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

</body>
</html>
