<?php
// Configurações do banco de dados
$host = "localhost"; 
$usuario = "root"; 
$senha = ""; 
$banco = "simcomp2";

// Conexão com o banco de dados
$conn = mysqli_connect($host, $usuario, $senha, $banco);

// Verifica se houve erro na conexão
if (mysqli_connect_errno()) {
    die("Falha na conexão com o banco de dados: " . mysqli_connect_error());
}

?>
