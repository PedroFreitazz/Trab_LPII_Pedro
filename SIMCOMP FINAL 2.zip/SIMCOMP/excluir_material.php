<?php
include_once "conecta.php";

if (isset($_GET['id'])) {
    $material_id = $_GET['id'];

    // Verificar se o formulário foi enviado para confirmar a exclusão
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Tentar excluir o material do banco de dados
        $excluir_query = "DELETE FROM Material WHERE Material_ID = $material_id";
        $excluir_resultado = mysqli_query($conn, $excluir_query);

        if (!$excluir_resultado) {
            $erro_exclusao = mysqli_error($conn);

            // Verificar se o erro é devido a uma restrição de chave estrangeira
            if (strpos($erro_exclusao, 'foreign key constraint fails') !== false) {
                $mensagem_nao_possivel_excluir = "Não é possível excluir o material.";
            } else {
                $mensagem_nao_possivel_excluir = "Erro na exclusão: " . $erro_exclusao;
            }
        } else {
            // Redirecionar de volta para a lista de materiais após a exclusão
            header("Location: lista_materiais.php");
            exit();
        }
    }
} else {
    die("ID do material não fornecido.");
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<a class="voltar"  href="cadmaterial.php">
  <img src="img\voltar.png" alt="Texto alternativo" placeholder="voltar";  title="clique aqui para voltar">
</a>
    <div class="container">
        <h1>Excluir Material</h1>

        <?php if (isset($mensagem_nao_possivel_excluir)) { ?>
            <p class="erro"><?php echo $mensagem_nao_possivel_excluir; ?></p>
        <?php } else { ?>
            <p>Tem certeza que deseja excluir este material?</p>

            <form method="post">
                <button type="submit">Sim, Excluir</button>
                <br></br>
                <a href="lista_materiais.php">Voltar</a>
            </form>
        <?php } ?>
    </div>
</body>
</html>
