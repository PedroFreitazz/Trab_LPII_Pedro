package com.example.sqlitebase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    EditText login, senha;
    Button entrar, cadastrar;
    DBHelper sql;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        login = findViewById(R.id.login);
        senha = findViewById(R.id.senha);
        entrar = findViewById(R.id.entrar);
        cadastrar = findViewById(R.id.cadastrar);

        sql = new DBHelper(this);

        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, cadastro.class);
                startActivity(i);
            }
        });
        entrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String nome = login.getText().toString().trim();
                String senha2 = senha.getText().toString().trim();

                if(nome.isEmpty()){
                    Toast.makeText(MainActivity.this, "Insira um usuário", Toast.LENGTH_SHORT).show();
                }
                else if (senha2.isEmpty()){
                    Toast.makeText(MainActivity.this, "Insira uma senha", Toast.LENGTH_SHORT).show();
                }
                else {
                   long resultado = sql.Select(nome, senha2);
                    if(resultado > 0 ){
                        Intent i = new Intent(MainActivity.this, acesso.class);
                        i.putExtra("username",nome);
                        i.putExtra("password", senha2);
                        i.putExtra("id", resultado);
                        startActivity(i);
                    }
                    else {
                        Toast.makeText(MainActivity.this, "Dados Incorretos", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}