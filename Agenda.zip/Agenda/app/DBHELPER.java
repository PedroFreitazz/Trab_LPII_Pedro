import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHELPER extends SQLiteOpenHelper {
    private  static  int versao = 1;
    private static  String nomeDB = "agenda.db";

    String[] sql = {"CREATE TABLE CONTATOS (id INTEGER, nome TEXT, telefone TEXT, email TEXT, PRIMARY KEY(id AUTOINCREMENT));"};

    public DBHelper(@Nullable Context context) {
        super(context, nomeDb, null, versao);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        for (int i = 0; i < sql.length; i++) {
            db.execSQL(sql[i]);
        }
    }
    public  long Update(int id , String nome,String telefone,String Email){
        SQLiteDatabase db = getWritableDatabase();
        ContentValues valor = new ContentValues();
        valor.put("telefone",telefone);
        return db.update("CONTATOS",valor,"id=?",new String[]{String.valueOf(id)});



    }
    public long Delete(int id){
        SQLiteDatabase db = getWritableDatabase();
        return db.delete("USUARIOS","id=?",new String[]{String.valueOf(id)});

    }
    @SuppressLint("Range")
    public  long select(String username, String password){
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM CO WHERE username=? AND "+"password=?",new String[]{username,password});
        c.moveToFirst();
        if(c.getCount()==1){
            return c.getInt(c.getColumnIndex("id"));
        }
        return -1;

    };


}
