<?php
include_once "conecta.php";

// Verifica se o ID da composteira foi fornecido via parâmetro GET
if (!isset($_GET['id'])) {
    echo "ID da composteira não fornecido.";
    exit;
}

$composteira_id = $_GET['id'];

// Consulta para excluir a composteira
$query_excluir_composteira = "DELETE FROM Composteira WHERE Composteira_ID = $composteira_id";
$resultado_excluir_composteira = mysqli_query($conn, $query_excluir_composteira);

// Verifica se a exclusão da composteira foi bem-sucedida
if ($resultado_excluir_composteira) {
    echo "Composteira excluída com sucesso.";
} else {
    echo "Erro ao excluir a composteira: " . mysqli_error($conn);
}
?>
