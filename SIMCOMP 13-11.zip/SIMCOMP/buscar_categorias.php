<?php
include_once("conecta.php");

// Busca as categorias da tabela Categoria
$result = $conn->query("SELECT Categoria_ID, Nome FROM Categoria");

// Inicializa uma string para armazenar as opções do menu suspenso
$options = '';

// Preenche o menu suspenso (dropdown) com as categorias
while ($row = $result->fetch_assoc()) {
    $options .= "<option value='" . $row['Categoria_ID'] . "'>" . $row['Nome'] . "</option>";
}

// Fecha a conexão com o banco de dados
$conn->close();

// Retorna as opções do menu suspenso
echo $options;
?>
