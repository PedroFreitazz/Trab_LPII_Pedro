function estilizarDiv(){
    var elemento = document.getElementsByTagName("div");
    elemento[0].style.background = "yellow";
    elemento[1].style.borderRadius = "10px";
    elemento[2].style.width = "80px";
    elemento[3].style.height = "80px";
    elemento[4].style.color = "green";
}