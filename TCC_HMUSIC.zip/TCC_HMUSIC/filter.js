function filterByGenre() {
    const genreSelect = document.getElementById("genre-select");
    const selectedGenre = genreSelect.value;

    const artistCards = document.querySelectorAll(".artist-card");

    artistCards.forEach(card => {
        const cardGenre = card.getAttribute("data-genre");

        if (selectedGenre === "todos" || selectedGenre === cardGenre) {
            card.style.display = "block";
        } else {
            card.style.display = "none";
        }
    });
}
